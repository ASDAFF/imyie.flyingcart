<?
global $DB, $MESS, $APPLICATION;

CModule::AddAutoloadClasses(
	"imyie.flyingcart",
	array(
		"CIMYIEFlyingCart" => "classes/general/main.php",
		"CIMYIEFlyingCartStyle" => "classes/general/style.php",
	)
);


?>