<?
IncludeModuleLangFile(__FILE__);

class CIMYIEFlyingCart
{
	function OnPrologHandler()
	{
		global $APPLICATION;
		if(!defined("ADMIN_SECTION"))
		{
			$APPLICATION->SetAdditionalCSS("/bitrix/modules/imyie.flyingcart/css/style.css");
		}
	}
	
	function OnEpilogHandler()
	{
		global $APPLICATION;
		if(!defined("ADMIN_SECTION") && CIMYIEFlyingCart::CheckShow())
		{
			$flyingcart_add_jquery = COption::GetOptionString("imyie.flyingcart", "flyingcart_add_jquery");
			if($flyingcart_add_jquery=="Y") CJSCore::Init('jquery');
			$APPLICATION->AddBufferContent(array("CIMYIEFlyingCart", "Add2Buffer"));
		}
	}
	
	function Add2Buffer()
	{
		global $APPLICATION;
		
		ob_start();

		/* include component */
		$APPLICATION->IncludeComponent("imyie:flyingcart",".default",Array());
		/* /include component */
		
		$html = ob_get_contents(); 
		ob_end_clean(); 
		
		return $html;
	}
	
	function GetNeededSize( $nowW, $nowH, $maxW, $maxH )
	{
		if($nowW>$maxW || $nowH>$maxH)
		{
			$factorW = $nowW/$maxW;
			$factorH = $nowH/$maxH;
			if($factorW>$factorH)
			{
				$trueW = $maxW;
				$trueH = floor($nowH/$factorW);
			} elseif($factorW<$factorH) {
				$trueW = floor($nowW/$factorH);
				$trueH = $maxH;
			} else {
				$trueW = $maxW;
				$trueH = $maxH;
			}
		} else {
			$trueW = $nowW;
			$trueH = $nowH;
		}
		return array( "WIDTH" => $trueW, "HEIGHT" => $trueH );
	}
	
	function CheckShow()
	{
		return CIMYIEFlyingCart::CheckShowByExteption();
	}
	
	function CheckShowByExteption()
	{
		global $APPLICATION;
		
		$flyingcart_pageexc_type = COption::GetOptionString("imyie.flyingcart", "flyingcart_pageexc_type", "none");
		$flyingcart_pageexc_list = unserialize( COption::GetOptionString("imyie.flyingcart", "flyingcart_pageexc_list", "") );
		$show = true;
		
		if($flyingcart_pageexc_type=="excteption")
		{
			$show = true;
			foreach($flyingcart_pageexc_list as $url)
			{
				$pos = strpos($APPLICATION->GetCurPage(), trim($url));
				if($pos!==false && $pos<1)
					$show = false;
			}
		} elseif($flyingcart_pageexc_type=="only")
		{
			$show = false;
			foreach($flyingcart_pageexc_list as $url)
			{
				$pos = strpos($APPLICATION->GetCurPage(), trim($url));
				if($pos!==false && $pos<1)
					$show = true;
			}
		}
		
		return $show;
	}
}
?>
