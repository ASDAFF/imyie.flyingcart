<?
IncludeModuleLangFile(__FILE__);

class CIMYIEFlyingCartStyle
{
	function GeneratorCSSAndRewrite()
	{
		CIMYIEFlyingCartStyle::SaveRequest();
		
		$fullCSS = "";
		$fullCSS.= CIMYIEFlyingCartStyle::Main();
		$fullCSS.= CIMYIEFlyingCartStyle::Header();
		$fullCSS.= CIMYIEFlyingCartStyle::ViewedProduct();
		$fullCSS.= CIMYIEFlyingCartStyle::Buttons();
		$fullCSS.= CIMYIEFlyingCartStyle::Basket();
		$fullCSS.= CIMYIEFlyingCartStyle::InputText();
		$fullCSS.= CIMYIEFlyingCartStyle::W8Window();
		$fullCSS.= CIMYIEFlyingCartStyle::Other();
		
		RewriteFile($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/imyie.flyingcart/css/style.css", $fullCSS);
	}
	
	function SaveRequest()
	{
		// easy styles
		COption::SetOptionInt("imyie.flyingcart", "flyingcart_visual_width", IntVal($_REQUEST["flyingcart_visual_width"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_width_pesr_px", ($_REQUEST["flyingcart_visual_width_pesr_px"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_header_border", ($_REQUEST["flyingcart_visual_color_header_border"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_link", ($_REQUEST["flyingcart_visual_color_link"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_link_hover", ($_REQUEST["flyingcart_visual_color_link_hover"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_inbasket_bg", ($_REQUEST["flyingcart_visual_color_inbasket_bg"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_inbasket_text", ($_REQUEST["flyingcart_visual_color_inbasket_text"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_oldprice_bg", ($_REQUEST["flyingcart_visual_color_oldprice_bg"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_oldprice_text", ($_REQUEST["flyingcart_visual_color_oldprice_text"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_price_bg", ($_REQUEST["flyingcart_visual_color_price_bg"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_price_text", ($_REQUEST["flyingcart_visual_color_price_text"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_bg", ($_REQUEST["flyingcart_visual_color_btn_bg"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_text", ($_REQUEST["flyingcart_visual_color_btn_text"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_bg_hover", ($_REQUEST["flyingcart_visual_color_btn_bg_hover"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_delete_bg", ($_REQUEST["flyingcart_visual_color_btn_delete_bg"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_delete_text", ($_REQUEST["flyingcart_visual_color_btn_delete_text"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_delete_bg_hover", ($_REQUEST["flyingcart_visual_color_btn_delete_bg_hover"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_input_border", ($_REQUEST["flyingcart_visual_color_input_border"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_note", ($_REQUEST["flyingcart_visual_color_note"]) );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_color_progress_bar", ($_REQUEST["flyingcart_visual_color_progress_bar"]) );
		// table
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_old_sver", $_REQUEST["flyingcart_visual_full_header_bg_old_sver"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_old_sverhover", $_REQUEST["flyingcart_visual_full_header_bg_old_sverhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_old_razv", $_REQUEST["flyingcart_visual_full_header_bg_old_razv"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_old_razvhover", $_REQUEST["flyingcart_visual_full_header_bg_old_razvhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradstart_sver", $_REQUEST["flyingcart_visual_full_header_bg_gradstart_sver"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradstart_sverhover", $_REQUEST["flyingcart_visual_full_header_bg_gradstart_sverhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradstart_razv", $_REQUEST["flyingcart_visual_full_header_bg_gradstart_razv"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradstart_razvhover", $_REQUEST["flyingcart_visual_full_header_bg_gradstart_razvhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradend_sver", $_REQUEST["flyingcart_visual_full_header_bg_gradend_sver"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradend_sverhover", $_REQUEST["flyingcart_visual_full_header_bg_gradend_sverhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradend_razv", $_REQUEST["flyingcart_visual_full_header_bg_gradend_razv"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradend_razvhover", $_REQUEST["flyingcart_visual_full_header_bg_gradend_razvhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_header_text_sver", $_REQUEST["flyingcart_visual_header_text_sver"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_header_text_sverhover", $_REQUEST["flyingcart_visual_header_text_sverhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_header_text_razv", $_REQUEST["flyingcart_visual_header_text_razv"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_header_text_razvhover", $_REQUEST["flyingcart_visual_header_text_razvhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_old_sver", $_REQUEST["flyingcart_visual_tab_header_bg_old_sver"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_old_sverhover", $_REQUEST["flyingcart_visual_tab_header_bg_old_sverhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_old_razv", $_REQUEST["flyingcart_visual_tab_header_bg_old_razv"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_old_razvhover", $_REQUEST["flyingcart_visual_tab_header_bg_old_razvhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradstart_sver", $_REQUEST["flyingcart_visual_tab_header_bg_gradstart_sver"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradstart_sverhover", $_REQUEST["flyingcart_visual_tab_header_bg_gradstart_sverhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradstart_razv", $_REQUEST["flyingcart_visual_tab_header_bg_gradstart_razv"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradstart_razvhover", $_REQUEST["flyingcart_visual_tab_header_bg_gradstart_razvhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradend_sver", $_REQUEST["flyingcart_visual_tab_header_bg_gradend_sver"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradend_sverhover", $_REQUEST["flyingcart_visual_tab_header_bg_gradend_sverhover"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradend_razv", $_REQUEST["flyingcart_visual_tab_header_bg_gradend_razv"] );
		COption::SetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradend_razvhover", $_REQUEST["flyingcart_visual_tab_header_bg_gradend_razvhover"] );
		// /table
		return TRUE;
	}
	
	//_______________________ Main _______________________//
	function Main()
	{
		$flyingcart_visual_width = COption::GetOptionInt("imyie.flyingcart", "flyingcart_visual_width", 80);
		$flyingcart_visual_width_pesr_px = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_width_pesr_px", "%");
$css = '
#imyie_flyingcart{
	position:fixed;
	bottom:0px;
	width:100%;
	height:30px;
	font:13px/18px Arial,Helvetica,sans-serif;
	z-index:1000;
}
#imyie_flyingcart .imyie_flyingcart{
	position:relative;
	width:'.$flyingcart_visual_width.''.$flyingcart_visual_width_pesr_px.';
	height:30px;
	margin:0 auto;
}
#imyie_flyingcart .imyie_flyingcart_inner{
	position:absolute;
	bottom:0px;
	padding:0px 1px;
	width:100%;
	height:30px;
	overflow:hidden;
}
';
		return $css;
	}
	
	//_______________________ Header _______________________//
	function Header()
	{
		$flyingcart_visual_color_header_border = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_header_border", "#13395a" );
		/* table */
		$flyingcart_visual_full_header_bg_old_sver = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_old_sver", "#124f85" );
		$flyingcart_visual_full_header_bg_old_sverhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_old_sverhover", "#124f85" );
		$flyingcart_visual_full_header_bg_old_razv = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_old_razv", "#124f85" );
		$flyingcart_visual_full_header_bg_old_razvhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_old_razvhover", "#124f85" );
		$flyingcart_visual_full_header_bg_gradstart_sver = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradstart_sver", "#124f85" );
		$flyingcart_visual_full_header_bg_gradstart_sverhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradstart_sverhover", "#124f85" );
		$flyingcart_visual_full_header_bg_gradstart_razv = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradstart_razv", "#124f85" );
		$flyingcart_visual_full_header_bg_gradstart_razvhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradstart_razvhover", "#124f85" );
		$flyingcart_visual_full_header_bg_gradend_sver = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradend_sver", "#2b7fbf" );
		$flyingcart_visual_full_header_bg_gradend_sverhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradend_sverhover", "#2b7fbf" );
		$flyingcart_visual_full_header_bg_gradend_razv = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradend_razv", "#2b7fbf" );
		$flyingcart_visual_full_header_bg_gradend_razvhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_full_header_bg_gradend_razvhover", "#2b7fbf" );
		$flyingcart_visual_header_text_sver = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_header_text_sver", "#FFFFFF" );
		$flyingcart_visual_header_text_sverhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_header_text_sverhover", "#FFFFFF" );
		$flyingcart_visual_header_text_razv = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_header_text_razv", "#000000" );
		$flyingcart_visual_header_text_razvhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_header_text_razvhover", "#F66B0E" );
		$flyingcart_visual_tab_header_bg_old_sver = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_old_sver", "#124f85" );
		$flyingcart_visual_tab_header_bg_old_sverhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_old_sverhover", "#124f85" );
		$flyingcart_visual_tab_header_bg_old_razv = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_old_razv", "#FFFFFF" );
		$flyingcart_visual_tab_header_bg_old_razvhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_old_razvhover", "#FFFFFF" );
		$flyingcart_visual_tab_header_bg_gradstart_sver = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradstart_sver", "#124f85" );
		$flyingcart_visual_tab_header_bg_gradstart_sverhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradstart_sverhover", "#124f85" );
		$flyingcart_visual_tab_header_bg_gradstart_razv = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradstart_razv", "#FFFFFF" );
		$flyingcart_visual_tab_header_bg_gradstart_razvhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradstart_razvhover", "#FFFFFF" );
		$flyingcart_visual_tab_header_bg_gradend_sver = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradend_sver", "#2b7fbf" );
		$flyingcart_visual_tab_header_bg_gradend_sverhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradend_sverhover", "#2b7fbf" );
		$flyingcart_visual_tab_header_bg_gradend_razv = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradend_razv", "#FFFFFF" );
		$flyingcart_visual_tab_header_bg_gradend_razvhover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_tab_header_bg_gradend_razvhover", "#FFFFFF" );
$css = '
#imyie_flyingcart .imyie_flyingcart-header{
	width:100%;
	height:30px;
	text-align:center;
	background-color:green;
	border-top:1px solid '.$flyingcart_visual_color_header_border.';
	border-right:1px solid '.$flyingcart_visual_color_header_border.';
	border-left:1px solid '.$flyingcart_visual_color_header_border.';
	border-radius:6px 6px 0 0;
	-moz-border-radius:6px 6px 0 0;
	-khtml-border-radius:6px 6px 0 0;
}
#imyie_flyingcart .svernut .imyie_flyingcart-header{
	background: '.$flyingcart_visual_full_header_bg_old_sver.';
	background: -moz-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_sver.', '.$flyingcart_visual_full_header_bg_gradend_sver.');
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,'.$flyingcart_visual_full_header_bg_gradstart_sver.'), color-stop(100%,'.$flyingcart_visual_full_header_bg_gradend_sver.'));
	background: -webkit-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_sve.', '.$flyingcart_visual_full_header_bg_gradend_sver.');
	background: -o-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_sver.', '.$flyingcart_visual_full_header_bg_gradend_sver.');
	background: -ms-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_sver.', '.$flyingcart_visual_full_header_bg_gradend_sver.');
	background: linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_sver.', '.$flyingcart_visual_full_header_bg_gradend_sver.');
}
#imyie_flyingcart .svernut .imyie_flyingcart-header:hover{
	background: '.$flyingcart_visual_full_header_bg_old_sverhover.';
	background: -moz-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_sverhover.', '.$flyingcart_visual_full_header_bg_gradend_sverhover.');
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,'.$flyingcart_visual_full_header_bg_gradstart_sverhover.'), color-stop(100%,'.$flyingcart_visual_full_header_bg_gradend_sverhover.'));
	background: -webkit-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_sverhover.', '.$flyingcart_visual_full_header_bg_gradend_sverhover.');
	background: -o-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_sverhover.', '.$flyingcart_visual_full_header_bg_gradend_sverhover.');
	background: -ms-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_sverhover.', '.$flyingcart_visual_full_header_bg_gradend_sverhover.');
	background: linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_sverhover.', '.$flyingcart_visual_full_header_bg_gradend_sverhover.');
}
#imyie_flyingcart .razvernut .imyie_flyingcart-header{
	background: '.$flyingcart_visual_full_header_bg_old_razv.';
	background: -moz-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_razv.', '.$flyingcart_visual_full_header_bg_gradend_razv.');
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,'.$flyingcart_visual_full_header_bg_gradstart_razv.'), color-stop(100%,'.$flyingcart_visual_full_header_bg_gradend_razv.'));
	background: -webkit-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_razv.', '.$flyingcart_visual_full_header_bg_gradend_razv.');
	background: -o-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_razv.', '.$flyingcart_visual_full_header_bg_gradend_razv.');
	background: -ms-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_razv.', '.$flyingcart_visual_full_header_bg_gradend_razv.');
	background: linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_razv.', '.$flyingcart_visual_full_header_bg_gradend_razv.');
}
#imyie_flyingcart .razvernut .imyie_flyingcart-header:hover{
	background: '.$flyingcart_visual_full_header_bg_old_razvhover.';
	background: -moz-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_razvhover.', '.$flyingcart_visual_full_header_bg_gradend_razvhover.');
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,'.$flyingcart_visual_full_header_bg_gradstart_razvhover.'), color-stop(100%,'.$flyingcart_visual_full_header_bg_gradend_razvhover.'));
	background: -webkit-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_razvhover.', '.$flyingcart_visual_full_header_bg_gradend_razvhover.');
	background: -o-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_razvhover.', '.$flyingcart_visual_full_header_bg_gradend_razvhover.');
	background: -ms-linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_razvhover.', '.$flyingcart_visual_full_header_bg_gradend_razvhover.');
	background: linear-gradient(top, '.$flyingcart_visual_full_header_bg_gradstart_razvhover.', '.$flyingcart_visual_full_header_bg_gradend_razvhover.');
}
#imyie_flyingcart .imyie_flyingcart-header-a{
	display:inline-block;
	padding:6px 10px 6px 10px;
	text-decoration:none;
	border-radius:6px 6px 0 0;
	-moz-border-radius:6px 6px 0 0;
	-khtml-border-radius:6px 6px 0 0;
}
#imyie_flyingcart .svernut .imyie_flyingcart-header-a{
	background: '.$flyingcart_visual_tab_header_bg_old_sver.';
	background: -moz-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sver.', '.$flyingcart_visual_tab_header_bg_gradend_sver.');
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,'.$flyingcart_visual_tab_header_bg_gradstart_sver.'), color-stop(100%,'.$flyingcart_visual_tab_header_bg_gradend_sver.'));
	background: -webkit-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sver.', '.$flyingcart_visual_tab_header_bg_gradend_sver.');
	background: -o-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sver.', '.$flyingcart_visual_tab_header_bg_gradend_sver.');
	background: -ms-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sver.', '.$flyingcart_visual_tab_header_bg_gradend_sver.');
	background: linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sver.', '.$flyingcart_visual_tab_header_bg_gradend_sver.');
}
#imyie_flyingcart .svernut .imyie_flyingcart-header-a:hover{
	background: '.$flyingcart_visual_tab_header_bg_old_sverhover.';
	background: -moz-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sverhover.', '.$flyingcart_visual_tab_header_bg_gradend_sverhover.');
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,'.$flyingcart_visual_tab_header_bg_gradstart_sverhover.'), color-stop(100%,'.$flyingcart_visual_tab_header_bg_gradend_sverhover.'));
	background: -webkit-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sverhover.', '.$flyingcart_visual_tab_header_bg_gradend_sverhover.');
	background: -o-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sverhover.', '.$flyingcart_visual_tab_header_bg_gradend_sverhover.');
	background: -ms-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sverhover.', '.$flyingcart_visual_tab_header_bg_gradend_sverhover.');
	background: linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sverhover.', '.$flyingcart_visual_tab_header_bg_gradend_sverhover.');
}
#imyie_flyingcart .razvernut .imyie_flyingcart-header-a{
	background: '.$flyingcart_visual_tab_header_bg_old_sver.';
	background: -moz-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sver.', '.$flyingcart_visual_tab_header_bg_gradend_sver.');
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,'.$flyingcart_visual_tab_header_bg_gradstart_sver.'), color-stop(100%,'.$flyingcart_visual_tab_header_bg_gradend_sver.'));
	background: -webkit-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sver.', '.$flyingcart_visual_tab_header_bg_gradend_sver.');
	background: -o-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sver.', '.$flyingcart_visual_tab_header_bg_gradend_sver.');
	background: -ms-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sver.', '.$flyingcart_visual_tab_header_bg_gradend_sver.');
	background: linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sver.', '.$flyingcart_visual_tab_header_bg_gradend_sver.');
}
#imyie_flyingcart .razvernut .imyie_flyingcart-header-a:hover{
	background: '.$flyingcart_visual_tab_header_bg_old_sverhover.';
	background: -moz-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sverhover.', '.$flyingcart_visual_tab_header_bg_gradend_sverhover.');
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,'.$flyingcart_visual_tab_header_bg_gradstart_sverhover.'), color-stop(100%,'.$flyingcart_visual_tab_header_bg_gradend_sverhover.'));
	background: -webkit-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sverhover.', '.$flyingcart_visual_tab_header_bg_gradend_sverhover.');
	background: -o-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sverhover.', '.$flyingcart_visual_tab_header_bg_gradend_sverhover.');
	background: -ms-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sverhover.', '.$flyingcart_visual_tab_header_bg_gradend_sverhover.');
	background: linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_sverhover.', '.$flyingcart_visual_tab_header_bg_gradend_sverhover.');
}
#imyie_flyingcart .razvernut .showed-tab{
	background: '.$flyingcart_visual_tab_header_bg_old_razv.';
	background: -moz-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_razv.', '.$flyingcart_visual_tab_header_bg_gradend_razv.');
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,'.$flyingcart_visual_tab_header_bg_gradstart_razv.'), color-stop(100%,'.$flyingcart_visual_tab_header_bg_gradend_razv.'));
	background: -webkit-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_razv.', '.$flyingcart_visual_tab_header_bg_gradend_razv.');
	background: -o-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_razv.', '.$flyingcart_visual_tab_header_bg_gradend_razv.');
	background: -ms-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_razv.', '.$flyingcart_visual_tab_header_bg_gradend_razv.');
	background: linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_razv.', '.$flyingcart_visual_tab_header_bg_gradend_razv.');
}
#imyie_flyingcart .razvernut .showed-tab:hover{
	background: '.$flyingcart_visual_tab_header_bg_old_razvhover.';
	background: -moz-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_razvhover.', '.$flyingcart_visual_tab_header_bg_gradend_razvhover.');
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,'.$flyingcart_visual_tab_header_bg_gradstart_razvhover.'), color-stop(100%,'.$flyingcart_visual_tab_header_bg_gradend_razvhover.'));
	background: -webkit-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_razvhover.', '.$flyingcart_visual_tab_header_bg_gradend_razvhover.');
	background: -o-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_razvhover.', '.$flyingcart_visual_tab_header_bg_gradend_razvhover.');
	background: -ms-linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_razvhover.', '.$flyingcart_visual_tab_header_bg_gradend_razvhover.');
	background: linear-gradient(top, '.$flyingcart_visual_tab_header_bg_gradstart_razvhover.', '.$flyingcart_visual_tab_header_bg_gradend_razvhover.');
}
#imyie_flyingcart .svernut .imyie_flyingcart-header-a span{
	border-bottom:1px dashed '.$flyingcart_visual_header_text_sver.';
	color:'.$flyingcart_visual_header_text_sver.';
}
#imyie_flyingcart .svernut .imyie_flyingcart-header-a:hover span{
	border-bottom:1px dashed '.$flyingcart_visual_header_text_sverhover.';
	color:'.$flyingcart_visual_header_text_sverhover.';
}
#imyie_flyingcart .razvernut .imyie_flyingcart-header-a span{
	border-bottom:1px dashed '.$flyingcart_visual_header_text_sver.';
	color:'.$flyingcart_visual_header_text_sver.';
}
#imyie_flyingcart .razvernut .imyie_flyingcart-header-a:hover span{
	border-bottom:1px dashed '.$flyingcart_visual_header_text_sverhover.';
	color:'.$flyingcart_visual_header_text_sverhover.';
}
#imyie_flyingcart .razvernut .showed-tab span{
	border-bottom:1px dashed '.$flyingcart_visual_header_text_razv.';
	color:'.$flyingcart_visual_header_text_razv.';
	-webkit-transition: color 0.2s ease;
}
#imyie_flyingcart .razvernut .showed-tab:hover span{
	border-bottom:1px dashed '.$flyingcart_visual_header_text_razvhover.';
	color:'.$flyingcart_visual_header_text_razvhover.';
}
#imyie_flyingcart .imyie_flyingcart-tabs{
	position:relative;
	height:220px;
	border-right:1px solid '.$flyingcart_visual_color_header_border.';
	border-left:1px solid '.$flyingcart_visual_color_header_border.';
	background-color:#FFFFFF;
}
';
		return $css;
	}
	
	//_______________________ ViewedProduct _______________________//
	function ViewedProduct()
	{
		$flyingcart_visual_color_link = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_link", "#124F85");
		$flyingcart_visual_color_link_hover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_link_hover", "#3F96E4");
		$flyingcart_visual_color_inbasket_bg = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_inbasket_bg", "#3f96e4");
		$flyingcart_visual_color_inbasket_text = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_inbasket_text", "#FFFFFF");
		$flyingcart_visual_color_oldprice_bg = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_oldprice_bg", "#999999");
		$flyingcart_visual_color_oldprice_text = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_oldprice_text", "#FFFFFF");
		$flyingcart_visual_color_price_bg = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_price_bg", "#124F85");
		$flyingcart_visual_color_price_text = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_price_text", "#FFFFFF");
$css = '
#imyie_flyingcart .imyie_flyingcart-viewed{
	height:220px;
	overflow:auto;
}
#imyie_flyingcart .imyie_flyingcart-viewed-item{
	position:relative;
	float:left;
	width:220px;
	height:200px;
	padding:10px;
}
#imyie_flyingcart .imyie_flyingcart-viewed-name{
	height:40px;
	overflow:hidden;
}
#imyie_flyingcart .imyie_flyingcart-viewed-link a{
	display:block;
	color:'.$flyingcart_visual_color_link.';
	text-decoration:underline;
}
#imyie_flyingcart .imyie_flyingcart-viewed-link a:hover{
	color:'.$flyingcart_visual_color_link_hover.';
	text-decoration:none;
}
#imyie_flyingcart .imyie_flyingcart-viewed-link a:hover .imyie_flyingcart-viewed-picture{
	filter:progid:DXImageTransform.Microsoft.Alpha(opacity=50);
	-moz-opacity:0.5;
	-khtml-opacity:0.5;
	opacity:0.5;
}
#imyie_flyingcart .imyie_flyingcart-viewed-picture{
	margin:5px;
}
#imyie_flyingcart .imyie_flyingcart-viewed-inbasket{
	width:125px;
	font-size:12px;
	background-color:'.$flyingcart_visual_color_inbasket_bg.';
	color:'.$flyingcart_visual_color_inbasket_text.';
	text-align:center;
	padding:3px 6px;
	border-radius:6px;
	-moz-border-radius:6px;
	-khtml-border-radius:6px;
}
#imyie_flyingcart .imyie_flyingcart-viewed-price-old_price{
	float:left;
	font-size:12px;
	text-decoration:line-through;
	background-color:'.$flyingcart_visual_color_oldprice_bg.';
	color:'.$flyingcart_visual_color_oldprice_text.';
	padding:3px 6px;
	margin-right:5px;
	border-radius:6px;
	-moz-border-radius:6px;
	-khtml-border-radius:6px;
}
#imyie_flyingcart .imyie_flyingcart-viewed-price-standart_price,
#imyie_flyingcart .imyie_flyingcart-viewed-price-new_price{
	float:left;
	font-size:14px;
	background-color:'.$flyingcart_visual_color_price_bg.';
	color:'.$flyingcart_visual_color_price_text.';
	padding:3px 6px;
	border-radius:6px;
	-moz-border-radius:6px;
	-khtml-border-radius:6px;
}
';
		return $css;
	}
	
	//_______________________ Buttons _______________________//
	function Buttons()
	{
		$flyingcart_visual_color_btn_bg = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_bg", "#124F85");
		$flyingcart_visual_color_btn_text = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_text", "#FFFFFF");
		$flyingcart_visual_color_btn_bg_hover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_bg_hover", "#3b92c6");
		$flyingcart_visual_color_btn_delete_bg = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_delete_bg", "#FF0000");
		$flyingcart_visual_color_btn_delete_text = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_delete_text", "#FFFFFF");
		$flyingcart_visual_color_btn_delete_bg_hover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_btn_delete_bg_hover", "#c53737");
$css = '
#imyie_flyingcart .imyie_flyingcart-add2basket{
	position:absolute;
	top:5px;
	left:5px;
}
#imyie_flyingcart .imyie_flyingcart-button_add2basket{
	border-radius:4px;
	-moz-border-radius:4px;
	-khtml-border-radius:4px;
	float:left;
	-webkit-transition-duration:0.2s, 0.2s;
	-webkit-transition-property:background-color, box-shadow;
	-webkit-transition-timing-function:cubic-bezier(0.25, 0.1, 0.25, 1), cubic-bezier(0.25, 0.1, 0.25, 1);
	background:'.$flyingcart_visual_color_btn_bg.'; /* ��� ������ �������� */
	border:0px;
	box-shadow:none;
	box-sizing:order-box;
	color:'.$flyingcart_visual_color_btn_text.';
	cursor:default;
	padding-bottom:2px;
	padding-left:6px;
	padding-right:6px;
	padding-top:2px;
	text-align:center;
	text-indent:0px;
	text-shadow:rgba(0, 0, 0, 0.347656) 0px -1px 0px;
	text-transform:none;
	vertical-align:middle;
	white-space:nowrap;
	word-spacing:0px;
	margin:0px;
	cursor:pointer;
}
#imyie_flyingcart .imyie_flyingcart-button_add2basket:hover{
	-moz-box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
	-webkit-box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
	box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
}
#imyie_flyingcart .imyie_flyingcart-input_quantity_plus,
#imyie_flyingcart .imyie_flyingcart-input_quantity_minus{
	float:left;
	-webkit-transition-duration:0.2s, 0.2s;
	-webkit-transition-property:background-color, box-shadow;
	-webkit-transition-timing-function:cubic-bezier(0.25, 0.1, 0.25, 1), cubic-bezier(0.25, 0.1, 0.25, 1);
	background:'.$flyingcart_visual_color_btn_bg.'; /* ��� ������ �������� */
	border:0px;
	box-shadow:none;
	box-sizing:order-box;
	color:'.$flyingcart_visual_color_btn_text.';
	cursor:default;
	padding-bottom:2px;
	padding-left:6px;
	padding-right:6px;
	padding-top:2px;
	text-align:center;
	text-indent:0px;
	text-shadow:rgba(0, 0, 0, 0.347656) 0px -1px 0px;
	text-transform:none;
	vertical-align:middle;
	white-space:nowrap;
	word-spacing:0px;
	margin:0px;
	cursor:pointer;
}
#imyie_flyingcart .imyie_flyingcart-input_quantity_plus:hover,
#imyie_flyingcart .imyie_flyingcart-input_quantity_minus:hover{
	-moz-box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
	-webkit-box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
	box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
}
#imyie_flyingcart .imyie_flyingcart-input_quantity_delete{
	float:left;
	-webkit-transition-duration:0.2s, 0.2s;
	-webkit-transition-property:background-color, box-shadow;
	-webkit-transition-timing-function:cubic-bezier(0.25, 0.1, 0.25, 1), cubic-bezier(0.25, 0.1, 0.25, 1);
	background:'.$flyingcart_visual_color_btn_delete_bg.'; /* ��� ������ �������� */
	border:0px;
	box-shadow:none;
	box-sizing:order-box;
	color:'.$flyingcart_visual_color_btn_delete_text.';
	cursor:default;
	padding-bottom:2px;
	padding-left:8px;
	padding-right:8px;
	padding-top:2px;
	text-align:center;
	text-indent:0px;
	text-shadow:rgba(0, 0, 0, 0.347656) 0px -1px 0px;
	text-transform:none;
	vertical-align:middle;
	white-space:nowrap;
	word-spacing:0px;
	margin:0px 0px 0px 5px;
	border-radius:4px;
	-moz-border-radius:4px;
	-khtml-border-radius:4px;
	cursor:pointer;
}
#imyie_flyingcart .imyie_flyingcart-input_quantity_delete:hover{
	-moz-box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_delete_bg_hover.';
	-webkit-box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_delete_bg_hover.';
	box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_delete_bg_hover.';
}
#imyie_flyingcart .imyie_flyingcart-input_quantity_plus{
	border-radius:0px 4px 4px 0px;
	-moz-border-radius:0px 4px 4px 0px;
	-khtml-border-radius:0px 4px 4px 0px;
}
#imyie_flyingcart .imyie_flyingcart-input_quantity_minus{
	border-radius:4px 0px 0px 4px;
	-moz-border-radius:4px 0px 0px 4px;
	-khtml-border-radius:4px 0px 0px 4px;
}
#imyie_flyingcart .imyie_flyingcart-button{
	-webkit-transition-duration:0.2s, 0.2s;
	-webkit-transition-property:background-color, box-shadow;
	-webkit-transition-timing-function:cubic-bezier(0.25, 0.1, 0.25, 1), cubic-bezier(0.25, 0.1, 0.25, 1);
	background:'.$flyingcart_visual_color_btn_bg.'; /* ��� ������ �������� */
	border:0px;
	border-bottom-left-radius:5px;
	border-bottom-right-radius:5px;
	border-top-left-radius:5px;
	border-top-right-radius:5px;
	box-shadow:none;
	box-sizing:order-box;
	color:'.$flyingcart_visual_color_btn_text.';
	cursor:default;
	height:30px;
	padding-bottom:4px;
	padding-left:9px;
	padding-right:9px;
	padding-top:4px;
	text-align:center;
	text-indent:0px;
	text-shadow:rgba(0, 0, 0, 0.347656) 0px -1px 0px;
	text-transform:none;
	vertical-align:middle;
	white-space:nowrap;
	word-spacing:0px;
	cursor:pointer;
}
#imyie_flyingcart .imyie_flyingcart-button:hover{
	-moz-box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
	-webkit-box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
	box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
}
#imyie_flyingcart .imyie_flyingcart-input_quantity_plus,
#imyie_flyingcart .imyie_flyingcart-input_quantity_minus{
	float:left;
	-webkit-transition-duration:0.2s, 0.2s;
	-webkit-transition-property:background-color, box-shadow;
	-webkit-transition-timing-function:cubic-bezier(0.25, 0.1, 0.25, 1), cubic-bezier(0.25, 0.1, 0.25, 1);
	background:'.$flyingcart_visual_color_btn_bg.'; /* ��� ������ �������� */
	border:0px;
	box-shadow:none;
	box-sizing:order-box;
	color:'.$flyingcart_visual_color_btn_text.';
	cursor:default;
	padding-bottom:2px;
	padding-left:6px;
	padding-right:6px;
	padding-top:2px;
	text-align:center;
	text-indent:0px;
	text-shadow:rgba(0, 0, 0, 0.347656) 0px -1px 0px;
	text-transform:none;
	vertical-align:middle;
	white-space:nowrap;
	word-spacing:0px;
	margin:0px;
	cursor:pointer;
}
#imyie_flyingcart .imyie_flyingcart-input_quantity_plus:hover,
#imyie_flyingcart .imyie_flyingcart-input_quantity_minus:hover{
	-moz-box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
	-webkit-box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
	box-shadow:0 0 4px 0 '.$flyingcart_visual_color_btn_bg_hover.';
}
';
		return $css;
	}
	
	//_______________________ Basket _______________________//
	function Basket()
	{
		$flyingcart_visual_color_link = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_link", "#124F85");
		$flyingcart_visual_color_link_hover = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_link_hover", "#3F96E4");
		$flyingcart_visual_color_note = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_note", "#13395a");
		$flyingcart_visual_color_price_bg = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_price_bg", "#124F85");
		$flyingcart_visual_color_price_text = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_price_text", "#FFFFFF");
$css = '
#imyie_flyingcart .imyie_flyingcart-basket{
	padding-right:180px;
	height:220px;
	overflow:auto;
}
#imyie_flyingcart .imyie_flyingcart-basket-item{
	float:left;
	width:220px;
	height:200px;
	padding:10px;
}
#imyie_flyingcart .imyie_flyingcart-basket-name{
	height:40px;
	overflow:hidden;
}
#imyie_flyingcart .imyie_flyingcart-basket-link a{
	display:block;
	color:'.$flyingcart_visual_color_link.';
	text-decoration:underline;
}
#imyie_flyingcart .imyie_flyingcart-basket-link a:hover{
	color:'.$flyingcart_visual_color_link_hover.';
	text-decoration:none;
}
#imyie_flyingcart .imyie_flyingcart-basket-link a:hover .imyie_flyingcart-basket-picture{
	filter:progid:DXImageTransform.Microsoft.Alpha(opacity=50);
	-moz-opacity:0.5;
	-khtml-opacity:0.5;
	opacity:0.5;
}
#imyie_flyingcart .imyie_flyingcart-basket-picture{
	margin:5px;
}
#imyie_flyingcart .imyie_flyingcart-basket-price{
	float:left;
	font-size:12px;
	background-color:'.$flyingcart_visual_color_price_bg.';
	color:'.$flyingcart_visual_color_price_text.';
	padding:3px 6px;
	border-radius:6px;
	-moz-border-radius:6px;
	-khtml-border-radius:6px;
}
#imyie_flyingcart .imyie_flyingcart-basket-note{
	position:absolute;
	top:0px;
	right:20px;
	float:right;
	width:180px;
	height:200px;
	padding:10px;
	border-left:1px dashed '.$flyingcart_visual_color_note.';
}
#imyie_flyingcart .imyie_flyingcart-basket-note_inner{
	margin:10px;
	font-size:11px;
	line-height:16px;
}
#imyie_flyingcart .imyie_flyingcart-basket-full_price{
	font-size:14px;
	font-weight:bold;
}
';
		return $css;
	}
	
	//_______________________ InputText _______________________//
	function InputText()
	{
		$flyingcart_visual_color_input_border = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_input_border", "#FF0000");
$css = '
#imyie_flyingcart .imyie_flyingcart-basket-quantity_delete{
	width:125px;
	background-color:white;
	margin-top:6px;
}
#imyie_flyingcart .imyie_flyingcart-input_quantity{
	float:left;
	width:30px;
	margin:0px;
	padding:1px 2px;
	border-top:1px solid '.$flyingcart_visual_color_input_border.';
	border-right:0px;
	border-bottom:1px solid '.$flyingcart_visual_color_input_border.';
	border-left:0px;
}
';
		return $css;
	}
	
	//_______________________ W8Window _______________________//
	function W8Window()
	{
		$flyingcart_visual_color_progress_bar = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_progress_bar", "#a5a5a5");
$css = '
#imyie_flyingcart .imyie_flyingcart-w8window{
	height:220px;
	overflow:hidden;
}
#imyie_flyingcart .imyie_flyingcart-w8window-blocks{
	width:150px;
	margin:0 auto;
	margin-top:105px;
}
#imyie_flyingcart .imyie_flyingcart-w8window-block{
	width:20px;
	height:5px;
	margin-right:5px;
	float:left;
	background-color:'.$flyingcart_visual_color_progress_bar.';
}
';
		return $css;
	}
	
	//_______________________ Other _______________________//
	function Other()
	{
$css = '
#imyie_flyingcart .imyie_flyingcart-clear{
	clear:both;
}
#imyie_flyingcart .imyie_flyingcart-none{
	display:none;
}
#imyie_flyingcart .imyie_flyingcart-overflow_hidden{
	overflow:hidden;
}
#imyie_flyingcart .imyie_flyingcart-overflow_auto{
	overflow:auto;
}
#imyie_flyingcart .imyie_flyingcart-while_empty{
	width:150px;
	padding-top:105px;
	padding-left:180px;
	margin:0 auto;
	text-align:center;
}
';
		return $css;
	}

	function ShowBColorPicker($name, $defaultValue="")
	{
		global $APPLICATION;
		
		$value = COption::GetOptionString("imyie.flyingcart", $name, $defaultValue);
		echo '<input type="text" size="6" maxlength="15" value="'.$value.'" name="'.$name.'" id="'.$name.'" />';
		$APPLICATION->IncludeComponent('bitrix:main.colorpicker', false, array(
				"ID" => $name,
				"NAME" => "",
				"SHOW_BUTTON" => "Y",
				"ONSELECT" => "OnColorPicker",
			)
		);
	}
	
	function GetSets()
	{
		$sets = array(
			"blue" => array(
				"NAME" => GetMessage("IMYIE_COLOR_BLUE_NAME"),
				"DATA" => array(
					"flyingcart_visual_color_header_border" => "#13395a",
					"flyingcart_visual_full_header_bg_old_sver" => "#124f85",
					"flyingcart_visual_full_header_bg_old_sverhover" => "#124f85",
					"flyingcart_visual_full_header_bg_old_razv" => "#124f85",
					"flyingcart_visual_full_header_bg_old_razvhover" => "#124f85",
					"flyingcart_visual_full_header_bg_gradstart_sver" => "#124f85",
					"flyingcart_visual_full_header_bg_gradstart_sverhover" => "#124f85",
					"flyingcart_visual_full_header_bg_gradstart_razv" => "#124f85",
					"flyingcart_visual_full_header_bg_gradstart_razvhover" => "#124f85",
					"flyingcart_visual_full_header_bg_gradend_sver" => "#2b7fbf",
					"flyingcart_visual_full_header_bg_gradend_sverhover" => "#2b7fbf",
					"flyingcart_visual_full_header_bg_gradend_razv" => "#2b7fbf",
					"flyingcart_visual_full_header_bg_gradend_razvhover" => "#2b7fbf",
					"flyingcart_visual_header_text_sver" => "#FFFFFF",
					"flyingcart_visual_header_text_sverhover" => "#FFFFFF",
					"flyingcart_visual_header_text_razv" => "#000000",
					"flyingcart_visual_header_text_razvhover" => "#F66B0E",
					"flyingcart_visual_tab_header_bg_old_sver" => "#296ca8",
					"flyingcart_visual_tab_header_bg_old_sverhover" => "#3c94d7",
					"flyingcart_visual_tab_header_bg_old_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_old_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_sver" => "#124f85",
					"flyingcart_visual_tab_header_bg_gradstart_sverhover" => "#2b7fbf",
					"flyingcart_visual_tab_header_bg_gradstart_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_sver" => "#2b7fbf",
					"flyingcart_visual_tab_header_bg_gradend_sverhover" => "#2b7fbf",
					"flyingcart_visual_tab_header_bg_gradend_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_razvhover" => "#FFFFFF",
					"flyingcart_visual_color_link" => "#124F85",
					"flyingcart_visual_color_link_hover" => "#3F96E4",
					"flyingcart_visual_color_inbasket_bg" => "#3f96e4",
					"flyingcart_visual_color_inbasket_text" => "#FFFFFF",
					"flyingcart_visual_color_oldprice_bg" => "#999999",
					"flyingcart_visual_color_oldprice_text" => "#FFFFFF",
					"flyingcart_visual_color_price_bg" => "#124F85",
					"flyingcart_visual_color_price_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg" => "#124F85",
					"flyingcart_visual_color_btn_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg_hover" => "#3b92c6",
					"flyingcart_visual_color_btn_delete_bg" => "#ff0000",
					"flyingcart_visual_color_btn_delete_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_delete_bg_hover" => "#c53737",
					"flyingcart_visual_color_input_border" => "#124F85",
					"flyingcart_visual_color_note" => "#124F85",
					"flyingcart_visual_color_progress_bar" => "#124F85",
				),
			),
			"orange" => array(
				"NAME" => GetMessage("IMYIE_COLOR_ORANGE_NAME"),
				"DATA" => array(
					"flyingcart_visual_color_header_border" => "#996600",
					"flyingcart_visual_full_header_bg_old_sver" => "#ff9900",
					"flyingcart_visual_full_header_bg_old_sverhover" => "#ff9900",
					"flyingcart_visual_full_header_bg_old_razv" => "#ff9900",
					"flyingcart_visual_full_header_bg_old_razvhover" => "#ff9900",
					"flyingcart_visual_full_header_bg_gradstart_sver" => "#ff9900",
					"flyingcart_visual_full_header_bg_gradstart_sverhover" => "#ff9900",
					"flyingcart_visual_full_header_bg_gradstart_razv" => "#ff9900",
					"flyingcart_visual_full_header_bg_gradstart_razvhover" => "#ff9900",
					"flyingcart_visual_full_header_bg_gradend_sver" => "#cc6600",
					"flyingcart_visual_full_header_bg_gradend_sverhover" => "#cc6600",
					"flyingcart_visual_full_header_bg_gradend_razv" => "#cc6600",
					"flyingcart_visual_full_header_bg_gradend_razvhover" => "#cc6600",
					"flyingcart_visual_header_text_sver" => "#FFFFFF",
					"flyingcart_visual_header_text_sverhover" => "#FFFFFF",
					"flyingcart_visual_header_text_razv" => "#000000",
					"flyingcart_visual_header_text_razvhover" => "#F66B0E",
					"flyingcart_visual_tab_header_bg_old_sver" => "#296ca8",
					"flyingcart_visual_tab_header_bg_old_sverhover" => "#3c94d7",
					"flyingcart_visual_tab_header_bg_old_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_old_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_sver" => "#ff9900",
					"flyingcart_visual_tab_header_bg_gradstart_sverhover" => "#cc6600",
					"flyingcart_visual_tab_header_bg_gradstart_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_sver" => "#cc6600",
					"flyingcart_visual_tab_header_bg_gradend_sverhover" => "#cc6600",
					"flyingcart_visual_tab_header_bg_gradend_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_razvhover" => "#FFFFFF",
					"flyingcart_visual_color_link" => "#ff9900",
					"flyingcart_visual_color_link_hover" => "#cc9933",
					"flyingcart_visual_color_inbasket_bg" => "#cc9933",
					"flyingcart_visual_color_inbasket_text" => "#FFFFFF",
					"flyingcart_visual_color_oldprice_bg" => "#999999",
					"flyingcart_visual_color_oldprice_text" => "#FFFFFF",
					"flyingcart_visual_color_price_bg" => "#ff9900",
					"flyingcart_visual_color_price_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg" => "#ff9900",
					"flyingcart_visual_color_btn_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg_hover" => "#ffcc99",
					"flyingcart_visual_color_btn_delete_bg" => "#ff0000",
					"flyingcart_visual_color_btn_delete_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_delete_bg_hover" => "#c53737",
					"flyingcart_visual_color_input_border" => "#ff9900",
					"flyingcart_visual_color_note" => "#ff9900",
					"flyingcart_visual_color_progress_bar" => "#ff9900",
				),
			),
			"green" => array(
				"NAME" => GetMessage("IMYIE_COLOR_GREEN_NAME"),
				"DATA" => array(
					"flyingcart_visual_color_header_border" => "#009900",
					"flyingcart_visual_full_header_bg_old_sver" => "#00cc00",
					"flyingcart_visual_full_header_bg_old_sverhover" => "#00cc00",
					"flyingcart_visual_full_header_bg_old_razv" => "#00cc00",
					"flyingcart_visual_full_header_bg_old_razvhover" => "#00cc00",
					"flyingcart_visual_full_header_bg_gradstart_sver" => "#00cc00",
					"flyingcart_visual_full_header_bg_gradstart_sverhover" => "#00cc00",
					"flyingcart_visual_full_header_bg_gradstart_razv" => "#00cc00",
					"flyingcart_visual_full_header_bg_gradstart_razvhover" => "#00cc00",
					"flyingcart_visual_full_header_bg_gradend_sver" => "#339933",
					"flyingcart_visual_full_header_bg_gradend_sverhover" => "#339933",
					"flyingcart_visual_full_header_bg_gradend_razv" => "#339933",
					"flyingcart_visual_full_header_bg_gradend_razvhover" => "#339933",
					"flyingcart_visual_header_text_sver" => "#FFFFFF",
					"flyingcart_visual_header_text_sverhover" => "#FFFFFF",
					"flyingcart_visual_header_text_razv" => "#000000",
					"flyingcart_visual_header_text_razvhover" => "#F66B0E",
					"flyingcart_visual_tab_header_bg_old_sver" => "#296ca8",
					"flyingcart_visual_tab_header_bg_old_sverhover" => "#3c94d7",
					"flyingcart_visual_tab_header_bg_old_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_old_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_sver" => "#00cc00",
					"flyingcart_visual_tab_header_bg_gradstart_sverhover" => "#339933",
					"flyingcart_visual_tab_header_bg_gradstart_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_sver" => "#339933",
					"flyingcart_visual_tab_header_bg_gradend_sverhover" => "#339933",
					"flyingcart_visual_tab_header_bg_gradend_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_razvhover" => "#FFFFFF",
					"flyingcart_visual_color_link" => "#00cc00",
					"flyingcart_visual_color_link_hover" => "#006600",
					"flyingcart_visual_color_inbasket_bg" => "#006600",
					"flyingcart_visual_color_inbasket_text" => "#FFFFFF",
					"flyingcart_visual_color_oldprice_bg" => "#999999",
					"flyingcart_visual_color_oldprice_text" => "#FFFFFF",
					"flyingcart_visual_color_price_bg" => "#00cc00",
					"flyingcart_visual_color_price_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg" => "#00cc00",
					"flyingcart_visual_color_btn_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg_hover" => "#006600",
					"flyingcart_visual_color_btn_delete_bg" => "#ff0000",
					"flyingcart_visual_color_btn_delete_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_delete_bg_hover" => "#c53737",
					"flyingcart_visual_color_input_border" => "#00cc00",
					"flyingcart_visual_color_note" => "#00cc00",
					"flyingcart_visual_color_progress_bar" => "#00cc00",
				),
			),
			"red" => array(
				"NAME" => GetMessage("IMYIE_COLOR_RED_NAME"),
				"DATA" => array(
					"flyingcart_visual_color_header_border" => "#660000",
					"flyingcart_visual_full_header_bg_old_sver" => "#ff0000",
					"flyingcart_visual_full_header_bg_old_sverhover" => "#ff0000",
					"flyingcart_visual_full_header_bg_old_razv" => "#ff0000",
					"flyingcart_visual_full_header_bg_old_razvhover" => "#ff0000",
					"flyingcart_visual_full_header_bg_gradstart_sver" => "#ff0000",
					"flyingcart_visual_full_header_bg_gradstart_sverhover" => "#ff0000",
					"flyingcart_visual_full_header_bg_gradstart_razv" => "#ff0000",
					"flyingcart_visual_full_header_bg_gradstart_razvhover" => "#ff0000",
					"flyingcart_visual_full_header_bg_gradend_sver" => "#cc0000",
					"flyingcart_visual_full_header_bg_gradend_sverhover" => "#cc0000",
					"flyingcart_visual_full_header_bg_gradend_razv" => "#cc0000",
					"flyingcart_visual_full_header_bg_gradend_razvhover" => "#cc0000",
					"flyingcart_visual_header_text_sver" => "#FFFFFF",
					"flyingcart_visual_header_text_sverhover" => "#FFFFFF",
					"flyingcart_visual_header_text_razv" => "#000000",
					"flyingcart_visual_header_text_razvhover" => "#F66B0E",
					"flyingcart_visual_tab_header_bg_old_sver" => "#296ca8",
					"flyingcart_visual_tab_header_bg_old_sverhover" => "#3c94d7",
					"flyingcart_visual_tab_header_bg_old_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_old_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_sver" => "#ff0000",
					"flyingcart_visual_tab_header_bg_gradstart_sverhover" => "#cc0000",
					"flyingcart_visual_tab_header_bg_gradstart_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_sver" => "#cc0000",
					"flyingcart_visual_tab_header_bg_gradend_sverhover" => "#cc0000",
					"flyingcart_visual_tab_header_bg_gradend_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_razvhover" => "#FFFFFF",
					"flyingcart_visual_color_link" => "#ff0000",
					"flyingcart_visual_color_link_hover" => "#990000",
					"flyingcart_visual_color_inbasket_bg" => "#990000",
					"flyingcart_visual_color_inbasket_text" => "#FFFFFF",
					"flyingcart_visual_color_oldprice_bg" => "#999999",
					"flyingcart_visual_color_oldprice_text" => "#FFFFFF",
					"flyingcart_visual_color_price_bg" => "#ff0000",
					"flyingcart_visual_color_price_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg" => "#ff0000",
					"flyingcart_visual_color_btn_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg_hover" => "#990000",
					"flyingcart_visual_color_btn_delete_bg" => "#ff0000",
					"flyingcart_visual_color_btn_delete_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_delete_bg_hover" => "#c53737",
					"flyingcart_visual_color_input_border" => "#ff0000",
					"flyingcart_visual_color_note" => "#ff0000",
					"flyingcart_visual_color_progress_bar" => "#ff0000",
				),
			),
			"yellow" => array(
				"NAME" => GetMessage("IMYIE_COLOR_YELLOW_NAME"),
				"DATA" => array(
					"flyingcart_visual_color_header_border" => "#999900",
					"flyingcart_visual_full_header_bg_old_sver" => "#ffff00",
					"flyingcart_visual_full_header_bg_old_sverhover" => "#ffff00",
					"flyingcart_visual_full_header_bg_old_razv" => "#ffff00",
					"flyingcart_visual_full_header_bg_old_razvhover" => "#ffff00",
					"flyingcart_visual_full_header_bg_gradstart_sver" => "#ffff00",
					"flyingcart_visual_full_header_bg_gradstart_sverhover" => "#ffff00",
					"flyingcart_visual_full_header_bg_gradstart_razv" => "#ffff00",
					"flyingcart_visual_full_header_bg_gradstart_razvhover" => "#ffff00",
					"flyingcart_visual_full_header_bg_gradend_sver" => "#cccc00",
					"flyingcart_visual_full_header_bg_gradend_sverhover" => "#cccc00",
					"flyingcart_visual_full_header_bg_gradend_razv" => "#cccc00",
					"flyingcart_visual_full_header_bg_gradend_razvhover" => "#cccc00",
					"flyingcart_visual_header_text_sver" => "#c53737",
					"flyingcart_visual_header_text_sverhover" => "#000000",
					"flyingcart_visual_header_text_razv" => "#000000",
					"flyingcart_visual_header_text_razvhover" => "#F66B0E",
					"flyingcart_visual_tab_header_bg_old_sver" => "#296ca8",
					"flyingcart_visual_tab_header_bg_old_sverhover" => "#3c94d7",
					"flyingcart_visual_tab_header_bg_old_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_old_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_sver" => "#ffff00",
					"flyingcart_visual_tab_header_bg_gradstart_sverhover" => "#cccc00",
					"flyingcart_visual_tab_header_bg_gradstart_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_sver" => "#cccc00",
					"flyingcart_visual_tab_header_bg_gradend_sverhover" => "#cccc00",
					"flyingcart_visual_tab_header_bg_gradend_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_razvhover" => "#FFFFFF",
					"flyingcart_visual_color_link" => "#999900",
					"flyingcart_visual_color_link_hover" => "#666600",
					"flyingcart_visual_color_inbasket_bg" => "#666600",
					"flyingcart_visual_color_inbasket_text" => "#FFFFFF",
					"flyingcart_visual_color_oldprice_bg" => "#999999",
					"flyingcart_visual_color_oldprice_text" => "#FFFFFF",
					"flyingcart_visual_color_price_bg" => "#999900",
					"flyingcart_visual_color_price_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg" => "#999900",
					"flyingcart_visual_color_btn_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg_hover" => "#666600",
					"flyingcart_visual_color_btn_delete_bg" => "#ff0000",
					"flyingcart_visual_color_btn_delete_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_delete_bg_hover" => "#c53737",
					"flyingcart_visual_color_input_border" => "#ffff00",
					"flyingcart_visual_color_note" => "#ffff00",
					"flyingcart_visual_color_progress_bar" => "#ffff00",
				),
			),
			"pink" => array(
				"NAME" => GetMessage("IMYIE_COLOR_PINK_NAME"),
				"DATA" => array(
					"flyingcart_visual_color_header_border" => "#660066",
					"flyingcart_visual_full_header_bg_old_sver" => "#cc00cc",
					"flyingcart_visual_full_header_bg_old_sverhover" => "#cc00cc",
					"flyingcart_visual_full_header_bg_old_razv" => "#cc00cc",
					"flyingcart_visual_full_header_bg_old_razvhover" => "#cc00cc",
					"flyingcart_visual_full_header_bg_gradstart_sver" => "#cc00cc",
					"flyingcart_visual_full_header_bg_gradstart_sverhover" => "#cc00cc",
					"flyingcart_visual_full_header_bg_gradstart_razv" => "#cc00cc",
					"flyingcart_visual_full_header_bg_gradstart_razvhover" => "#cc00cc",
					"flyingcart_visual_full_header_bg_gradend_sver" => "#990099",
					"flyingcart_visual_full_header_bg_gradend_sverhover" => "#990099",
					"flyingcart_visual_full_header_bg_gradend_razv" => "#990099",
					"flyingcart_visual_full_header_bg_gradend_razvhover" => "#990099",
					"flyingcart_visual_header_text_sver" => "#FFFFFF",
					"flyingcart_visual_header_text_sverhover" => "#FFFFFF",
					"flyingcart_visual_header_text_razv" => "#000000",
					"flyingcart_visual_header_text_razvhover" => "#F66B0E",
					"flyingcart_visual_tab_header_bg_old_sver" => "#296ca8",
					"flyingcart_visual_tab_header_bg_old_sverhover" => "#3c94d7",
					"flyingcart_visual_tab_header_bg_old_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_old_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_sver" => "#cc00cc",
					"flyingcart_visual_tab_header_bg_gradstart_sverhover" => "#990099",
					"flyingcart_visual_tab_header_bg_gradstart_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_sver" => "#990099",
					"flyingcart_visual_tab_header_bg_gradend_sverhover" => "#990099",
					"flyingcart_visual_tab_header_bg_gradend_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_razvhover" => "#FFFFFF",
					"flyingcart_visual_color_link" => "#cc00cc",
					"flyingcart_visual_color_link_hover" => "#660066",
					"flyingcart_visual_color_inbasket_bg" => "#660066",
					"flyingcart_visual_color_inbasket_text" => "#FFFFFF",
					"flyingcart_visual_color_oldprice_bg" => "#999999",
					"flyingcart_visual_color_oldprice_text" => "#FFFFFF",
					"flyingcart_visual_color_price_bg" => "#cc00cc",
					"flyingcart_visual_color_price_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg" => "#cc00cc",
					"flyingcart_visual_color_btn_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg_hover" => "#660066",
					"flyingcart_visual_color_btn_delete_bg" => "#ff0000",
					"flyingcart_visual_color_btn_delete_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_delete_bg_hover" => "#c53737",
					"flyingcart_visual_color_input_border" => "#cc00cc",
					"flyingcart_visual_color_note" => "#cc00cc",
					"flyingcart_visual_color_progress_bar" => "#cc00cc",
				),
			),
			"purple" => array(
				"NAME" => GetMessage("IMYIE_COLOR_PURPLE_NAME"),
				"DATA" => array(
					"flyingcart_visual_color_header_border" => "#330066",
					"flyingcart_visual_full_header_bg_old_sver" => "#6600cc",
					"flyingcart_visual_full_header_bg_old_sverhover" => "#6600cc",
					"flyingcart_visual_full_header_bg_old_razv" => "#6600cc",
					"flyingcart_visual_full_header_bg_old_razvhover" => "#6600cc",
					"flyingcart_visual_full_header_bg_gradstart_sver" => "#6600cc",
					"flyingcart_visual_full_header_bg_gradstart_sverhover" => "#6600cc",
					"flyingcart_visual_full_header_bg_gradstart_razv" => "#6600cc",
					"flyingcart_visual_full_header_bg_gradstart_razvhover" => "#6600cc",
					"flyingcart_visual_full_header_bg_gradend_sver" => "#660099",
					"flyingcart_visual_full_header_bg_gradend_sverhover" => "#660099",
					"flyingcart_visual_full_header_bg_gradend_razv" => "#660099",
					"flyingcart_visual_full_header_bg_gradend_razvhover" => "#660099",
					"flyingcart_visual_header_text_sver" => "#FFFFFF",
					"flyingcart_visual_header_text_sverhover" => "#FFFFFF",
					"flyingcart_visual_header_text_razv" => "#000000",
					"flyingcart_visual_header_text_razvhover" => "#F66B0E",
					"flyingcart_visual_tab_header_bg_old_sver" => "#296ca8",
					"flyingcart_visual_tab_header_bg_old_sverhover" => "#3c94d7",
					"flyingcart_visual_tab_header_bg_old_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_old_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_sver" => "#6600cc",
					"flyingcart_visual_tab_header_bg_gradstart_sverhover" => "#660099",
					"flyingcart_visual_tab_header_bg_gradstart_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_sver" => "#660099",
					"flyingcart_visual_tab_header_bg_gradend_sverhover" => "#660099",
					"flyingcart_visual_tab_header_bg_gradend_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_razvhover" => "#FFFFFF",
					"flyingcart_visual_color_link" => "#6600cc",
					"flyingcart_visual_color_link_hover" => "#9933cc",
					"flyingcart_visual_color_inbasket_bg" => "#9933cc",
					"flyingcart_visual_color_inbasket_text" => "#FFFFFF",
					"flyingcart_visual_color_oldprice_bg" => "#999999",
					"flyingcart_visual_color_oldprice_text" => "#FFFFFF",
					"flyingcart_visual_color_price_bg" => "#6600cc",
					"flyingcart_visual_color_price_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg" => "#6600cc",
					"flyingcart_visual_color_btn_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg_hover" => "#9933cc",
					"flyingcart_visual_color_btn_delete_bg" => "#ff0000",
					"flyingcart_visual_color_btn_delete_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_delete_bg_hover" => "#c53737",
					"flyingcart_visual_color_input_border" => "#6600cc",
					"flyingcart_visual_color_note" => "#6600cc",
					"flyingcart_visual_color_progress_bar" => "#6600cc",
				),
			),
			"black" => array(
				"NAME" => GetMessage("IMYIE_COLOR_BLACK_NAME"),
				"DATA" => array(
					"flyingcart_visual_color_header_border" => "#000000",
					"flyingcart_visual_full_header_bg_old_sver" => "#666666",
					"flyingcart_visual_full_header_bg_old_sverhover" => "#666666",
					"flyingcart_visual_full_header_bg_old_razv" => "#666666",
					"flyingcart_visual_full_header_bg_old_razvhover" => "#666666",
					"flyingcart_visual_full_header_bg_gradstart_sver" => "#666666",
					"flyingcart_visual_full_header_bg_gradstart_sverhover" => "#666666",
					"flyingcart_visual_full_header_bg_gradstart_razv" => "#666666",
					"flyingcart_visual_full_header_bg_gradstart_razvhover" => "#666666",
					"flyingcart_visual_full_header_bg_gradend_sver" => "#333333",
					"flyingcart_visual_full_header_bg_gradend_sverhover" => "#333333",
					"flyingcart_visual_full_header_bg_gradend_razv" => "#333333",
					"flyingcart_visual_full_header_bg_gradend_razvhover" => "#333333",
					"flyingcart_visual_header_text_sver" => "#FFFFFF",
					"flyingcart_visual_header_text_sverhover" => "#FFFFFF",
					"flyingcart_visual_header_text_razv" => "#000000",
					"flyingcart_visual_header_text_razvhover" => "#F66B0E",
					"flyingcart_visual_tab_header_bg_old_sver" => "#296ca8",
					"flyingcart_visual_tab_header_bg_old_sverhover" => "#3c94d7",
					"flyingcart_visual_tab_header_bg_old_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_old_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_sver" => "#666666",
					"flyingcart_visual_tab_header_bg_gradstart_sverhover" => "#333333",
					"flyingcart_visual_tab_header_bg_gradstart_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradstart_razvhover" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_sver" => "#333333",
					"flyingcart_visual_tab_header_bg_gradend_sverhover" => "#333333",
					"flyingcart_visual_tab_header_bg_gradend_razv" => "#FFFFFF",
					"flyingcart_visual_tab_header_bg_gradend_razvhover" => "#FFFFFF",
					"flyingcart_visual_color_link" => "#666666",
					"flyingcart_visual_color_link_hover" => "#000000",
					"flyingcart_visual_color_inbasket_bg" => "#666666",
					"flyingcart_visual_color_inbasket_text" => "#FFFFFF",
					"flyingcart_visual_color_oldprice_bg" => "#FFFFFF",
					"flyingcart_visual_color_oldprice_text" => "#000000",
					"flyingcart_visual_color_price_bg" => "#666666",
					"flyingcart_visual_color_price_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg" => "#666666",
					"flyingcart_visual_color_btn_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_bg_hover" => "#000000",
					"flyingcart_visual_color_btn_delete_bg" => "#ff0000",
					"flyingcart_visual_color_btn_delete_text" => "#FFFFFF",
					"flyingcart_visual_color_btn_delete_bg_hover" => "#c53737",
					"flyingcart_visual_color_input_border" => "#666666",
					"flyingcart_visual_color_note" => "#666666",
					"flyingcart_visual_color_progress_bar" => "#666666",
				),
			),
		);
		return $sets;
	}
}
?>
