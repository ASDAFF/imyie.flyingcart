<?
global $MESS;
IncludeModuleLangFile(__FILE__);

Class imyie_flyingcart extends CModule
{
    var $MODULE_ID = "imyie.flyingcart";
	var $MODULE_VERSION;
	var $MODULE_VERSION_DATE;
	var $MODULE_NAME;
	var $MODULE_DESCRIPTION;
	var $MODULE_CSS;
	var $MODULE_GROUP_RIGHTS = "Y";

	function imyie_flyingcart()
	{
		$arModuleVersion = array();

		$path = str_replace("\\", "/", __FILE__);
		$path = substr($path, 0, strlen($path) - strlen("/index.php"));
		include($path."/version.php");
	
        if (is_array($arModuleVersion) && array_key_exists("VERSION", $arModuleVersion)) {
            $this->MODULE_VERSION = $arModuleVersion["VERSION"];
            $this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
        } else {
            $this->MODULE_VERSION = "1.0.0";
            $this->MODULE_VERSION_DATE = "2012.01.01";
        }

		$this->MODULE_NAME = GetMessage("IMYIE_INSTALL_NAME");
		$this->MODULE_DESCRIPTION = GetMessage("IMYIE_INSTALL_DESCRIPTION");
		$this->PARTNER_NAME = GetMessage("IMYIE_INSTALL_COPMPANY_NAME");
        $this->PARTNER_URI  = "http://imyie.ru/";
	}

	// Install functions
	function InstallDB()
	{
		global $DB, $DBType, $APPLICATION;
		RegisterModule("imyie.flyingcart");
		/* options */
			COption::SetOptionString("imyie.flyingcart", "flyingcart_add_type", "auto" );
			COption::SetOptionInt("imyie.flyingcart", "IBLOCK_ID", 0 );
			COption::SetOptionString("imyie.flyingcart", "flyingcart_price_code", "");
			COption::SetOptionString("imyie.flyingcart", "flyingcart_currency_id", "" );
			COption::SetOptionString("imyie.flyingcart", "flyingcart_tab_viewed_name", GetMessage("IMYIE_INSTALL_DATA_TAB1_NAME") );
			COption::SetOptionString("imyie.flyingcart", "flyingcart_tab_basket_name", GetMessage("IMYIE_INSTALL_DATA_TAB2_NAME") );
			COption::SetOptionString("imyie.flyingcart", "flyingcart_link_order_make", "" );
			COption::SetOptionString("imyie.flyingcart", "flyingcart_overflow_viewed", "N" );
			COption::SetOptionInt("imyie.flyingcart", "flyingcart_viewed_count", 20 );
		/* /options */
		return TRUE;
	}

	function InstallFiles()
	{
		CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/imyie.flyingcart/install/components", $_SERVER["DOCUMENT_ROOT"]."/bitrix/components", true, true);
		return TRUE;
	}

	function InstallPublic()
	{
		return TRUE;
	}

	function InstallEvents()
	{
		RegisterModuleDependences("main", "OnProlog", "imyie.flyingcart", "CIMYIEFlyingCart", "OnPrologHandler", "500");
		RegisterModuleDependences("main", "OnEpilog", "imyie.flyingcart", "CIMYIEFlyingCart", "OnEpilogHandler", "500");
		return TRUE;
	}

	// UnInstal functions
	function UnInstallDB()
	{
		global $DB, $DBType, $APPLICATION;
		COption::RemoveOption("imyie.flyingcart");
		UnRegisterModule("imyie.flyingcart");
		return TRUE;
	}

	function UnInstallFiles()
	{
		return TRUE;
	}

	function UnInstallPublic()
	{
		return TRUE;
	}

	function UnInstallEvents()
	{
		UnRegisterModuleDependences("main", "OnProlog", "imyie.flyingcart", "CIMYIEFlyingCart", "OnPrologHandler");
		UnRegisterModuleDependences("main", "OnEpilog", "imyie.flyingcart", "CIMYIEFlyingCart", "OnEpilogHandler");
		return TRUE;
	}

    function DoInstall()
    {
		global $APPLICATION, $step;
		$keyGoodDB = $this->InstallDB();
		$keyGoodEvents = $this->InstallEvents();
		$keyGoodFiles = $this->InstallFiles();
		$keyGoodPublic = $this->InstallPublic();
		$APPLICATION->IncludeAdminFile(GetMessage("SPER_INSTALL_TITLE"), $_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/imyie.flyingcart/install/install.php");
    }

    function DoUninstall()
    {
		global $APPLICATION, $step;
		$keyGoodFiles = $this->UnInstallFiles();
		$keyGoodEvents = $this->UnInstallEvents();
		$keyGoodDB = $this->UnInstallDB();
		$keyGoodPublic = $this->UnInstallPublic();
		$APPLICATION->IncludeAdminFile(GetMessage("SPER_UNINSTALL_TITLE"), $_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/imyie.flyingcart/install/uninstall.php");
    }
}
?>