<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

// component version - 1.0.2

if(!CModule::IncludeModule('imyie.flyingcart'))
{
	ShowError("IMYIE_ERROR_MODULE_NOT_INSTALLED");
	return;
}
if(!CModule::IncludeModule('sale'))
{
	ShowError("IMYIE_ERROR_SALE_NOT_INSTALLED");
	return;
}
if(!CModule::IncludeModule('iblock'))
{
	ShowError("IMYIE_ERROR_IBLOCK_NOT_INSTALLED");
	return;
}
if(!CModule::IncludeModule('catalog'))
{
	ShowError("IMYIE_ERROR_CATALOG_NOT_INSTALLED");
	return;
}

global $APPLICATION;

$arParams["PICTURE"]["MAX_WIDTH"] = 180;
$arParams["PICTURE"]["MAX_HEIGHT"] = 90;
$arParams["SITE_ID"] = COption::GetOptionString("imyie.flyingcart", "flyingcart_site_id", "s1");
$arParams["BASKET_USER_ID"] = CSaleBasket::GetBasketUserID();
$arParams["IBLOCK_ID"] = COption::GetOptionInt("imyie.flyingcart", "IBLOCK_ID", 0 );
$arParams["PRICE_CODE"] = COption::GetOptionString("imyie.flyingcart", "flyingcart_price_code");
$arParams["CURERNCY_ID"] = COption::GetOptionString("imyie.flyingcart", "flyingcart_currency_id");
$arParams["LANG_NAME_VIEWED"] = COption::GetOptionString("imyie.flyingcart", "flyingcart_tab_viewed_name", GetMessage("IMYIE_TAB_NAME_VIEWED") );
$arParams["LANG_NAME_BASKET"] = COption::GetOptionString("imyie.flyingcart", "flyingcart_tab_basket_name", GetMessage("IMYIE_TAB_NAME_BASKET") );
$arParams["LINK_ORDER_MAKE"] = COption::GetOptionString("imyie.flyingcart", "flyingcart_link_order_make");
$arParams["VIEWED_OVERFLOW"] = COption::GetOptionString("imyie.flyingcart", "flyingcart_overflow_viewed", "N");
$arParams["VIEWED_COUNT"] = COption::GetOptionInt("imyie.flyingcart", "flyingcart_viewed_count", 20);
$arParams["BODY_PADDING"] = COption::GetOptionString("imyie.flyingcart", "flyingcart_body_padding", "Y");
$arParams["W8WINDOW"]["BLOCK_COLOR"] = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_color_progress_bar", "#124F85");
$arParams["AJAX_ACTION_NAME"] = "mode";
$arParams["AJAX_ACTION_VAL"] = "imyie_flyingcart_ajax";

$arResult["AJAX_REQUEST"] = "N";
$arResult["AJAX_GET"] = "";

if($_REQUEST[$arParams["AJAX_ACTION_NAME"]]==$arParams["AJAX_ACTION_VAL"])
{
	$arParams["CACHE_TIME"] = 1;
	$APPLICATION->RestartBuffer();
	$arResult["AJAX_REQUEST"] = "Y";
	$arResult["SHOW_TAB"] = ($_REQUEST["showed_tab"] == "viewed" ? "viewed" : "basket");
} else {
	$arParams["CACHE_TIME"] = 1;//3600
}

/* REQUEST basket refresh */
if (strlen($_REQUEST["BasketRefresh"]) > 0 || strlen($_REQUEST["BasketOrder"]) > 0)
{
	$dbBasketItems = CSaleBasket::GetList(
			array("PRICE" => "DESC"),
			array(
					"FUSER_ID" => $arParams["BASKET_USER_ID"],
					"LID" => $arParams["SITE_ID"],
					"ORDER_ID" => "NULL"
				),
			false,
			false,
			array("ID", "CALLBACK_FUNC", "MODULE", "PRODUCT_ID", "QUANTITY", "DELAY", "CAN_BUY", "CURRENCY", "SUBSCRIBE")
		);
	while ($arBasketItems = $dbBasketItems->Fetch())
	{
		$arBasketItems['QUANTITY'] = IntVal($arBasketItems['QUANTITY']);

		if(!isset($_REQUEST["QUANTITY_".$arBasketItems["ID"]]))
			$quantityTmp = IntVal($arBasketItems['QUANTITY']);
		else
			$quantityTmp = IntVal($_REQUEST["QUANTITY_".$arBasketItems["ID"]]);
		
		$deleteTmp = (($_REQUEST["DELETE_".$arBasketItems["ID"]] == "Y") ? "Y" : "N");

		if ($deleteTmp == "Y")
		{
			CSaleBasket::Delete($arBasketItems["ID"]);
		}
		elseif ($arBasketItems["DELAY"] == "N" && $arBasketItems["CAN_BUY"] == "Y")
		{
			UnSet($arFields);
			$arFields = array();
			$arFields["QUANTITY"] = $quantityTmp;

			if (count($arFields) > 0 && ($arBasketItems["QUANTITY"] != $arFields["QUANTITY"]) )
			{
				CSaleBasket::Update($arBasketItems["ID"], $arFields);
			}
		}
	}

	unset($_SESSION["SALE_BASKET_NUM_PRODUCTS"][$arParams["SITE_ID"]]);
}
CSaleBasket::UpdateBasketPrices($arParams["BASKET_USER_ID"], $arParams["SITE_ID"]);

/* REQUEST add2basket */
if($_REQUEST[$arParams["AJAX_ACTION_NAME"]]==$arParams["AJAX_ACTION_VAL"] && IntVal($_REQUEST["add_id"])>0)
{
	if (CModule::IncludeModule("sale") && CModule::IncludeModule("catalog") && CModule::IncludeModule('iblock'))
	{
		Add2BasketByProductID( IntVal($_REQUEST["add_id"]) );
	}
}

$allSum = 0;
$allWeight = 0;
$allCurrency = CSaleLang::GetLangCurrency($arParams["SITE_ID"]);
$allVATSum = 0;

if ($this->StartResultCache($arParams["CACHE_TIME"]))
{
	$arResultPrices = CIBlockPriceTools::GetCatalogPrices($arParams["IBLOCK_ID"], array($arParams["PRICE_CODE"]));
	
	// ________________________________________________________________________________________________________________________ //
	// basket
		$arBasketItems = array();
		$arBasketId = array();
		$dbBasketItems = CSaleBasket::GetList(
			array("NAME" => "ASC", "ID" => "ASC"),
			array(
				"FUSER_ID" => $arParams["BASKET_USER_ID"],
				"LID" => $arParams["SITE_ID"],
				"ORDER_ID" => "NULL"
			),
			false,
			false,
			array("ID", "NAME", "CALLBACK_FUNC", "MODULE", "PRODUCT_ID", "QUANTITY", "DELAY", "CAN_BUY", "PRICE", "WEIGHT", "DETAIL_PAGE_URL", "NOTES", "CURRENCY", "VAT_RATE", "CATALOG_XML_ID", "PRODUCT_XML_ID", "SUBSCRIBE", "DISCOUNT_PRICE")
		);
		while ($arItem = $dbBasketItems->GetNext())
		{
			$arBasketId[] = $arItem["PRODUCT_ID"];
			$arBasketItems[$arItem["PRODUCT_ID"]] = $arItem;
		}
		
		if(is_array($arBasketId) && count($arBasketId)>0)
		{
			$arrProducts = array();
			$res = CIBlockElement::GetList(Array(), array("ID" => $arBasketId), false, false, array("*", "CATALOG_GROUP_".$arResultPrices[$arParams["PRICE_CODE"]]["ID"]));
			while ($arElements = $res->GetNext())
			{
				$arElements["BASKET_ID"] = $arBasketItems[$arElements["ID"]]["ID"];
				
				$arElements["PRICE_VAT_VALUE"] = (($arBasketItems[$arElements["ID"]]["PRICE"] / ($arBasketItems[$arElements["ID"]]["VAT_RATE"] +1)) * $arBasketItems[$arElements["ID"]]["VAT_RATE"]);
				$arElements["PRICE_FORMATED"] = SaleFormatCurrency($arBasketItems[$arElements["ID"]]["PRICE"], $arBasketItems[$arElements["ID"]]["CURRENCY"]);
				
				$arElements["DELAY"] = $arBasketItems[$arElements["ID"]]["DELAY"];
				$arElements["CAN_BUY"] = $arBasketItems[$arElements["ID"]]["CAN_BUY"];
				$arElements["DISCOUNT_PRICE"] = $arBasketItems[$arElements["ID"]]["DISCOUNT_PRICE"];
				$arElements["PRICE"] = $arBasketItems[$arElements["ID"]]["PRICE"];
				$arElements["QUANTITY"] = IntVal($arBasketItems[$arElements["ID"]]["QUANTITY"]);
				
				$arElements["PREVIEW_PICTURE"] = CFile::GetFileArray( $arElements["PREVIEW_PICTURE"] );
				$arElements["PREVIEW_PICTURE"]["NEEDED_SIZE"] = CIMYIEFlyingCart::GetNeededSize(
					$arElements["PREVIEW_PICTURE"]["WIDTH"],
					$arElements["PREVIEW_PICTURE"]["HEIGHT"],
					$arParams["PICTURE"]["MAX_WIDTH"],
					$arParams["PICTURE"]["MAX_HEIGHT"]
				);
				
				$arElements["DETAIL_PICTURE"] = CFile::GetFileArray( $arElements["DETAIL_PICTURE"] );
				$arElements["DETAIL_PICTURE"]["NEEDED_SIZE"] = CIMYIEFlyingCart::GetNeededSize(
					$arElements["DETAIL_PICTURE"]["WIDTH"],
					$arElements["DETAIL_PICTURE"]["HEIGHT"],
					$arParams["PICTURE"]["MAX_WIDTH"],
					$arParams["PICTURE"]["MAX_HEIGHT"]
				);
				
				if ($arElements["DELAY"] == "N" && $arElements["CAN_BUY"] == "Y")
				{
					$allSum += ($arElements["PRICE"] * $arElements["QUANTITY"]);
					$allWeight += ($arElements["WEIGHT"] * $arElements["QUANTITY"]);
					$allVATSum += roundEx($arElements["PRICE_VAT_VALUE"] * $arElements["QUANTITY"], SALE_VALUE_PRECISION);
				}

				if ($arElements["DELAY"] == "N" && $arElements["CAN_BUY"] == "Y")
				{
					$bShowReady = True;
					if(DoubleVal($arElements["DISCOUNT_PRICE"]) > 0)
					{
						$arElements["DISCOUNT_PRICE_PERCENT"] = $arElements["DISCOUNT_PRICE"]*100 / ($arElements["DISCOUNT_PRICE"] + $arElements["PRICE"]);
						$arElements["DISCOUNT_PRICE_PERCENT_FORMATED"] = roundEx($arElements["DISCOUNT_PRICE_PERCENT"], SALE_VALUE_PRECISION)."%";
						$DISCOUNT_PRICE_ALL += $arElements["DISCOUNT_PRICE"] * $arElements["QUANTITY"];
					}
					$arrProducts["AnDelCanBuy"][] = $arElements;
				}
				elseif ($arElements["DELAY"] == "Y" && $arElements["CAN_BUY"] == "Y")
				{
					$bShowDelay = True;
					$arrProducts["DelDelCanBuy"][] = $arElements;
				}
				elseif ($arElements["CAN_BUY"] == "N" && $arElements["SUBSCRIBE"] == "Y")
				{
					$bShowSubscribe = True;
					$arrProducts["ProdSubscribe"][] = $arElements;
				}
				else
				{
					$bShowNotAvail = True;
					$arrProducts["nAnCanBuy"][] = $arElements;
				}
			}
			$arResult["BASKET"]["ITEMS"] = $arrProducts;
			
			$arResult["BASKET"]["ShowReady"] = (($bShowReady)?"Y":"N");
			$arResult["BASKET"]["ShowDelay"] = (($bShowDelay)?"Y":"N");
			$arResult["BASKET"]["ShowNotAvail"] = (($bShowNotAvail)?"Y":"N");
			$arResult["BASKET"]["ShowSubscribe"] = (($bShowSubscribe)?"Y":"N");

			$dbDiscount = CSaleDiscount::GetList(
					array("SORT" => "ASC"),
					array(
							"LID" => $arParams["SITE_ID"],
							"ACTIVE" => "Y",
							"!>ACTIVE_FROM" => Date($DB->DateFormatToPHP(CSite::GetDateFormat("FULL"))),
							"!<ACTIVE_TO" => Date($DB->DateFormatToPHP(CSite::GetDateFormat("FULL"))),
							"<=PRICE_FROM" => $allSum,
							">=PRICE_TO" => $allSum,
							"USER_GROUPS" => $USER->GetUserGroupArray(),
						),
					false,
					false,
					array("*")
				);
			$arMinDiscount = array();
			$dblMinPrice = $allSum;
			$arResult["BASKET"]["DISCOUNT_PRICE"] = 0;
			$arResult["BASKET"]["DISCOUNT_PERCENT"] = 0;
			while ($arDiscount = $dbDiscount->Fetch())
			{
				$dblDiscount = 0;
				$allSum_tmp = $allSum;
				if ($arDiscount["DISCOUNT_TYPE"] == "P")
				{
					if($arParams["COUNT_DISCOUNT_4_ALL_QUANTITY"] == "Y")
					{
						foreach ($arResult["BASKET"]["ITEMS"]["AnDelCanBuy"] as $arResultItem)
						{
							$curDiscount = roundEx(DoubleVal($arResultItem["PRICE"]) * DoubleVal($arResultItem["QUANTITY"]) * $arDiscount["DISCOUNT_VALUE"] / 100, SALE_VALUE_PRECISION);
							$dblDiscount += $curDiscount;
						}
					}
					else
					{
						foreach ($arResult["BASKET"]["ITEMS"]["AnDelCanBuy"] as $arResultItem)
						{
							$curDiscount = roundEx(DoubleVal($arResultItem["PRICE"]) * $arDiscount["DISCOUNT_VALUE"] / 100, SALE_VALUE_PRECISION);
							$dblDiscount += $curDiscount * DoubleVal($arResultItem["QUANTITY"]);
						}
					}
				}
				else
				{
					$dblDiscount = roundEx(CCurrencyRates::ConvertCurrency($arDiscount["DISCOUNT_VALUE"], $arDiscount["CURRENCY"], $allCurrency), SALE_VALUE_PRECISION);
				}
				$allSum = $allSum - $dblDiscount;
				
				if ($dblMinPrice > $allSum)
				{
					$dblMinPrice = $allSum;
					$arMinDiscount = $arDiscount;
				}
				$allSum = $allSum_tmp;
			}

			if (!empty($arMinDiscount))
			{
				if ($arMinDiscount["DISCOUNT_TYPE"] == "P")
				{
					$arResult["BASKET"]["DISCOUNT_PERCENT"] = $arMinDiscount["DISCOUNT_VALUE"];
					for ($bi = 0; $bi < count($arResult["BASKET"]["ITEMS"]["AnDelCanBuy"]); $bi++)
					{
						if($arParams["COUNT_DISCOUNT_4_ALL_QUANTITY"] == "Y")
						{
							$curDiscount = roundEx(DoubleVal($arResult["BASKET"]["ITEMS"]["AnDelCanBuy"][$bi]["PRICE"]) * DoubleVal($arResult["BASKET"]["ITEMS"]["AnDelCanBuy"][$bi]["QUANTITY"]) * $arMinDiscount["DISCOUNT_VALUE"] / 100, SALE_VALUE_PRECISION);
							$arResult["BASKET"]["DISCOUNT_PRICE"] += $curDiscount;
						}
						else
						{
							$curDiscount = roundEx(DoubleVal($arResult["BASKET"]["ITEMS"]["AnDelCanBuy"][$bi]["PRICE"]) * $arMinDiscount["DISCOUNT_VALUE"] / 100, SALE_VALUE_PRECISION);
							$arResult["BASKET"]["DISCOUNT_PRICE"] += $curDiscount * DoubleVal($arResult["BASKET"]["ITEMS"]["AnDelCanBuy"][$bi]["QUANTITY"]);
						}
					}
					$arResult["BASKET"]["DISCOUNT_PERCENT_FORMATED"] = DoubleVal($arResult["BASKET"]["DISCOUNT_PERCENT"])."%";
				}
				else
				{
					$arResult["BASKET"]["DISCOUNT_PRICE"] = CCurrencyRates::ConvertCurrency($arMinDiscount["DISCOUNT_VALUE"], $arMinDiscount["CURRENCY"], $allCurrency);
					$arResult["BASKET"]["DISCOUNT_PRICE"] = roundEx($arResult["BASKET"]["DISCOUNT_PRICE"], SALE_VALUE_PRECISION);
				}
				$allSum = $allSum - $arResult["BASKET"]["DISCOUNT_PRICE"];
			}
			
			$DISCOUNT_PRICE_ALL += $arResult["BASKET"]["DISCOUNT_PRICE"];
			$arResult["BASKET"]["allSum"] = $allSum;
			$arResult["BASKET"]["allWeight"] = $allWeight;
			$arResult["BASKET"]["allWeight_FORMATED"] = roundEx(DoubleVal($allWeight/$arParams["WEIGHT_KOEF"]), SALE_VALUE_PRECISION)." ".$arParams["WEIGHT_UNIT"];
			$arResult["BASKET"]["allSum_FORMATED"] = SaleFormatCurrency($allSum, $allCurrency);
			$arResult["BASKET"]["DISCOUNT_PRICE_FORMATED"] = SaleFormatCurrency($arResult["BASKET"]["DISCOUNT_PRICE"], $allCurrency);

			if ($arParams['PRICE_VAT_SHOW_VALUE'] == 'Y')
			{
				$arResult["BASKET"]["allVATSum"] = $allVATSum;
				$arResult["BASKET"]["allVATSum_FORMATED"] = SaleFormatCurrency($allVATSum, $allCurrency);
				$arResult["BASKET"]["allSum_wVAT_FORMATED"] = SaleFormatCurrency($arResult["BASKET"]["allSum_wVAT"], $allCurrency);
			}

			if ($arParams["HIDE_COUPON"] != "Y")
				$arCoupons = CCatalogDiscount::GetCoupons();

			if (count($arCoupons) > 0)
				$arResult["BASKET"]["COUPON"] = htmlspecialcharsbx($arCoupons[0]);
			if(count($arBasketItems)<=0)
				$arResult["BASKET"]["ERROR_MESSAGE"] = GetMessage("SALE_EMPTY_BASKET");

			$arResult["BASKET"]["DISCOUNT_PRICE_ALL"] = $DISCOUNT_PRICE_ALL;
			$arResult["BASKET"]["DISCOUNT_PRICE_ALL_FORMATED"] = SaleFormatCurrency($DISCOUNT_PRICE_ALL, $allCurrency);
		}
	// ________________________________________________________________________________________________________________________ //
	// viewed product part
		// get viewed product
		$arViewed = array();
		$arViewedId = array();
		$arFilter = array(
			"LID" => $arParams["SITE_ID"],
			"FUSER_ID" => CSaleBasket::GetBasketUserID(),
		);
		$arOrder = array("DATE_VISIT" => "DESC");
		$arNavStartParams = array("nTopCount" => $arParams["VIEWED_COUNT"]);
		$arSelect = array("*");
		$res = CSaleViewedProduct::GetList($arOrder,$arFilter,false,$arNavStartParams,$arSelect);
		while ($arItems = $res->Fetch())
		{
			$arViewedId[] = $arItems["PRODUCT_ID"];
			$arViewed[$arItems["PRODUCT_ID"]] = $arItems;
		}
		
		// get elements
		//, array('ID', 'IBLOCK_ID', 'IBLOCK_SECTION_ID')
		if(is_array($arViewedId) && count($arViewedId)>0)
		{
			$arrProducts = array();
			$res = CIBlockElement::GetList(Array(), array("ID" => $arViewedId), false, false, array("*", "CATALOG_GROUP_".$arResultPrices[$arParams["PRICE_CODE"]]["ID"]));
			while ($arElements = $res->GetNext())
			{
				$arItems = $arElements;
				
				$arItems["CAT_PRICES"] = $arResultPrices;
				$arItems["PRICE_MATRIX"] = CatalogGetPriceTableEx($arItems["ID"], 0, array($arResultPrices[$arParams["PRICE_CODE"]]["ID"]), "Y");
				$arItems["PRICES"] = CIBlockPriceTools::GetItemPrices($arItems["IBLOCK_ID"], $arItems["CAT_PRICES"], $arItems);
				
				foreach($arItems["PRICES"] as $priceCode => $price)
				{
					$arItems["PRICES"][$priceCode]["DISCOUNT"] = round($price["VALUE"]-$price["DISCOUNT_VALUE"]);
					$arItems["PRICES"][$priceCode]["PRINT_DISCOUNT"] = FormatCurrency($arItems["PRICES"][$priceCode]["DISCOUNT"], $arParams["CURERNCY_ID"]);
				}
				
				$arItems["PRICE_MATRIX"] = false;
				
				$arItems["CAN_BUY"] = CIBlockPriceTools::CanBuy($arItems["IBLOCK_ID"], $arItems["CAT_PRICES"], $arItems);
				
				$arItems["BUY_URL"] = htmlspecialcharsex($APPLICATION->GetCurPageParam($arParams["ACTION_VARIABLE"]."=BUY&".$arParams["PRODUCT_ID_VARIABLE"]."=".$arItems["PRODUCT_ID"], array($arParams["PRODUCT_ID_VARIABLE"], $arParams["ACTION_VARIABLE"])));
				$arItems["ADD_URL"] = htmlspecialcharsex($APPLICATION->GetCurPageParam($arParams["ACTION_VARIABLE"]."=ADD2BASKET&".$arParams["PRODUCT_ID_VARIABLE"]."=".$arItems["PRODUCT_ID"], array($arParams["PRODUCT_ID_VARIABLE"], $arParams["ACTION_VARIABLE"])));
				
				$arItems["PREVIEW_PICTURE"] = CFile::GetFileArray( $arElements["PREVIEW_PICTURE"] );
				$arItems["PREVIEW_PICTURE"]["NEEDED_SIZE"] = CIMYIEFlyingCart::GetNeededSize(
					$arItems["PREVIEW_PICTURE"]["WIDTH"],
					$arItems["PREVIEW_PICTURE"]["HEIGHT"],
					$arParams["PICTURE"]["MAX_WIDTH"],
					$arParams["PICTURE"]["MAX_HEIGHT"]
				);
				
				$arItems["DETAIL_PICTURE"] = CFile::GetFileArray( $arElements["DETAIL_PICTURE"] );
				$arItems["DETAIL_PICTURE"]["NEEDED_SIZE"] = CIMYIEFlyingCart::GetNeededSize(
					$arItems["DETAIL_PICTURE"]["WIDTH"],
					$arItems["DETAIL_PICTURE"]["HEIGHT"],
					$arParams["PICTURE"]["MAX_WIDTH"],
					$arParams["PICTURE"]["MAX_HEIGHT"]
				);
				
				if(in_array($arItems["ID"], $arBasketId))
					$arItems["PRODUCT_IN_BASKET"] = "Y";
				else
					$arItems["PRODUCT_IN_BASKET"] = "N";
				
				$arrProducts[] = $arItems;
				
			}
			$arResult["VIEWED_PRODUCT"] = $arrProducts;
		} else {
			$arResult["VIEWED_PRODUCT"] = array();
		}
	// ________________________________________________________________________________________________________________________ //
	
	// include component template
	$this->IncludeComponentTemplate();
}
?>