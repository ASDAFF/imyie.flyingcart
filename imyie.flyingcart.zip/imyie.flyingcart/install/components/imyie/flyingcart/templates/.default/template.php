<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?if($arResult["AJAX_REQUEST"]!="Y"):?>
	<script type="text/javascript" src="<?=$templateFolder."/jscript.js"?>"></script>
	
	<script type="text/javascript">
	var imyie_flyingcart_ajax_path = "<?echo $templateFolder."/ajax.php";?>";
	var imyie_flyingcart_body_padding = "<?if($arParams["BODY_PADDING"]=="Y"):?>Y<?else:?>N<?endif;?>";
	var imyie_flyingcart_w8window_block_color = "<?=$arParams["W8WINDOW"]["BLOCK_COLOR"]?>";
	</script>

	<div id="imyie_flyingcart">
		<div class="imyie_flyingcart">
			<div class="imyie_flyingcart_inner svernut">
				<div class="imyie_flyingcart-header">
					<a class="imyie_flyingcart-header-a" href="tab1"><span><?=$arParams["LANG_NAME_VIEWED"]?></span></a>
					<a class="imyie_flyingcart-header-a" href="tab2"><span><?=$arParams["LANG_NAME_BASKET"]?></span></a>
				</div>
				<div class="imyie_flyingcart-tabs">
<?endif;?>
					<div class="imyie_flyingcart-tab imyie_flyingcart-tab1"<?if($arResult["AJAX_REQUEST"]=="Y" && $arResult["SHOW_TAB"]=="basket"):?>style="display:none;"<?endif;?>>
						<div class="imyie_flyingcart-viewed <?if($arParams["VIEWED_OVERFLOW"]=="Y"):?>imyie_flyingcart-overflow_auto<?else:?>imyie_flyingcart-overflow_hidden<?endif;?>">
							<?if(count($arResult["VIEWED_PRODUCT"])>0):?>
								<?foreach($arResult["VIEWED_PRODUCT"] as $key => $product):?>
									<div class="imyie_flyingcart-viewed-item">
										<div class="imyie_flyingcart-viewed-link">
											<a href="<?=$product["DETAIL_PAGE_URL"]?>">
												<?if(is_array($product["PREVIEW_PICTURE"]) && $product["PREVIEW_PICTURE"]["SRC"]!=""):?>
													<img class="imyie_flyingcart-viewed-picture" src="<?=$product["PREVIEW_PICTURE"]["SRC"]?>" <?
														?>width="<?=$product["PREVIEW_PICTURE"]["NEEDED_SIZE"]["WIDTH"]?>" <?
														?>height="<?=$product["PREVIEW_PICTURE"]["NEEDED_SIZE"]["HEIGHT"]?>" <?
														?>border="0" title="<?=$product["NAME"]?>" alt="<?=$product["NAME"]?>" />
												<?elseif(is_array($product["DETAIL_PICTURE"]) && $product["DETAIL_PICTURE"]["SRC"]!=""):?>
													<img class="imyie_flyingcart-viewed-picture" src="<?=$product["DETAIL_PICTURE"]["SRC"]?>" <?
														?>width="<?=$product["DETAIL_PICTURE"]["NEEDED_SIZE"]["WIDTH"]?>" <?
														?>height="<?=$product["DETAIL_PICTURE"]["NEEDED_SIZE"]["HEIGHT"]?>" <?
														?>border="0" title="<?=$product["NAME"]?>" alt="<?=$product["NAME"]?>" />
												<?else:?>
													<div class="imyie_flyingcart-viewed-no_image"></div>
												<?endif;?>
												<div class="imyie_flyingcart-viewed-name"><?=$product["NAME"]?></div>
											</a>
										</div>
										<?if($product["PRODUCT_IN_BASKET"]=="Y"):?>
											<div class="imyie_flyingcart-viewed-inbasket">
												<?=GetMessage("IMYIE_ALREADY_IN_BASKET")?>
											</div>
										<?else:?>
											<?if(count($product["PRICES"])>0):?>
												<div class="imyie_flyingcart-viewed-price">
													<?if($product["PRICES"][$arParams["PRICE_CODE"]]["DISCOUNT"]>0):?>
														<div class="imyie_flyingcart-viewed-price-old_price">
															<?=$product["PRICES"][$arParams["PRICE_CODE"]]["PRINT_VALUE"]?>
														</div>
														<div class="imyie_flyingcart-viewed-price-new_price">
															<?=$product["PRICES"][$arParams["PRICE_CODE"]]["PRINT_DISCOUNT_VALUE"]?>
														</div>
													<?else:?>
														<div class="imyie_flyingcart-viewed-price-standart_price">
															<?=$product["PRICES"][$arParams["PRICE_CODE"]]["PRINT_DISCOUNT_VALUE"]?>
														</div>
													<?endif;?>
												</div>
											<?endif;?>
										<?endif;?>
										<?if($product["CAN_BUY"] && $product["PRODUCT_IN_BASKET"]!="Y"):?>
											<div class="imyie_flyingcart-add2basket">
												<input class="imyie_flyingcart-button_add2basket" data-id="<?=$product["ID"]?>" type="button" title="<?=GetMessage("IMYIE_TITLE_ADDBASKET")?>" value="+" />
											</div>
										<?endif;?>
									</div>
								<?endforeach;?>
							<?else:?>
								<div class="imyie_flyingcart-while_empty" style="padding-right:180px;"><?=GetMessage("IMYIE_WHILE_EMPTY")?></div>
							<?endif;?>
						</div>
					</div>
					<div class="imyie_flyingcart-tab imyie_flyingcart-tab2"<?if($arResult["AJAX_REQUEST"]=="Y" && $arResult["SHOW_TAB"]=="viewed"):?>style="display:none;"<?endif;?>>
						<div class="imyie_flyingcart-basket">
							<form class="imyie_flyingcart-basket-form" method="post" action="<?echo $templateFolder."/ajax.php";?>" name="basket_form">
								<?if(count($arResult["BASKET"]["ITEMS"]["AnDelCanBuy"])>0):?>
									<?foreach($arResult["BASKET"]["ITEMS"]["AnDelCanBuy"] as $key => $product):?>
										<div class="imyie_flyingcart-basket-item">
											<div class="imyie_flyingcart-basket-link">
												<a href="<?=$product["DETAIL_PAGE_URL"]?>">
													<?if(is_array($product["PREVIEW_PICTURE"]) && $product["PREVIEW_PICTURE"]["SRC"]!=""):?>
														<img class="imyie_flyingcart-basket-picture" src="<?=$product["PREVIEW_PICTURE"]["SRC"]?>" <?
															?>width="<?=$product["PREVIEW_PICTURE"]["NEEDED_SIZE"]["WIDTH"]?>" <?
															?>height="<?=$product["PREVIEW_PICTURE"]["NEEDED_SIZE"]["HEIGHT"]?>" <?
															?>border="0" title="<?=$product["NAME"]?>" alt="<?=$product["NAME"]?>" />
													<?elseif(is_array($product["DETAIL_PICTURE"]) && $product["DETAIL_PICTURE"]["SRC"]!=""):?>
														<img class="imyie_flyingcart-basket-picture" src="<?=$product["DETAIL_PICTURE"]["SRC"]?>" <?
															?>width="<?=$product["DETAIL_PICTURE"]["NEEDED_SIZE"]["WIDTH"]?>" <?
															?>height="<?=$product["DETAIL_PICTURE"]["NEEDED_SIZE"]["HEIGHT"]?>" <?
															?>border="0" title="<?=$product["NAME"]?>" alt="<?=$product["NAME"]?>" />
													<?else:?>
														<div class="imyie_flyingcart-basket-no_image"></div>
													<?endif;?>
													<div class="imyie_flyingcart-basket-name"><?=$product["NAME"]?></div>
												</a>
											</div>
											<div class="imyie_flyingcart-basket-price">
												<?=$product["PRICE_FORMATED"]?>
											</div>
											<div class="imyie_flyingcart-clear"></div>
											<!-- quantity and delete -->
											<div class="imyie_flyingcart-basket-quantity_delete">
												<div class="imyie_flyingcart-basket-quantity">
													<input class="imyie_flyingcart-input_quantity_minus" data-id="<?=$product["BASKET_ID"]?>" type="button" value="&minus;" />
													<input class="imyie_flyingcart-input_quantity" maxlength="18" type="text" name="QUANTITY_<?=$product["BASKET_ID"]?>" value="<?=$product["QUANTITY"]?>" >
													<input class="imyie_flyingcart-input_quantity_plus" data-id="<?=$product["BASKET_ID"]?>" type="button" value="+" />
												</div>
												<div class="imyie_flyingcart-basket-delete">
													<input class="imyie_flyingcart-input_quantity_delete" type="button" title="<?=GetMessage("IMYIE_TITLE_DELETE")?>" id="<?=$key?>" value="X" />
													<input class="imyie_flyingcart-input_delete imyie_flyingcart-none" type="checkbox" name="DELETE_<?=$product["BASKET_ID"]?>" id="DELETE_<?=$key?>" value="Y">
												</div>
											</div>
											<!-- /quantity and delete -->
											<div class="imyie_flyingcart-clear"></div>
										</div>
									<?endforeach;?>
									<div class="imyie_flyingcart-basket-note">
										<div class="imyie_flyingcart-basket-note_inner">
											<?=GetMessage("IMYIE_FULL_PRICE")?>:<br /><span class="imyie_flyingcart-basket-full_price"><?=$arResult["BASKET"]["allSum_FORMATED"]?></span><br />
											<br />
											<input type="submit" name="BasketRefresh" value="<?=GetMessage("IMYIE_BTN_REFRESH")?>" class="imyie_flyingcart-button imyie_flyingcart-button_refresh" id="flyingbasketBasketRefresh"><br />
											<br />
											<input type="submit" name="BasketOrder" value="<?=GetMessage("IMYIE_BTN_ORDER")?>" onclick="window.location='<?=$arParams["LINK_ORDER_MAKE"]?>'; return false;" class="imyie_flyingcart-button imyie_flyingcart-button_order" id="flyingbasketBasketOrder">
										</div>
									</div>
								<?else:?>
									<div class="imyie_flyingcart-while_empty"><?=GetMessage("IMYIE_WHILE_EMPTY")?></div>
								<?endif;?>
							</form>
						</div>
					</div>
<?if($arResult["AJAX_REQUEST"]!="Y"):?>
				</div>
			</div>
		</div>
	</div>
<?endif;?>