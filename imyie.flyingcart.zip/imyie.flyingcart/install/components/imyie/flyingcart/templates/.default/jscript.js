var intervalID = 0;
var cnt = 1;
function IMYIEFLYINGCART_w8window(status)
{
	var w8window = '<div class="imyie_flyingcart-w8window"><div class="imyie_flyingcart-w8window-blocks">' + 
			'<div class="imyie_flyingcart-w8window-block imyie_flyingcart-w8window-block1"></div>' + 
			'<div class="imyie_flyingcart-w8window-block imyie_flyingcart-w8window-block2"></div>' + 
			'<div class="imyie_flyingcart-w8window-block imyie_flyingcart-w8window-block3"></div>' + 
			'<div class="imyie_flyingcart-w8window-block imyie_flyingcart-w8window-block4"></div>' + 
			'<div class="imyie_flyingcart-w8window-block imyie_flyingcart-w8window-block5"></div>' + 
			'<div class="imyie_flyingcart-w8window-block imyie_flyingcart-w8window-block6"></div>' + 
		'</div>' + 
	'</div>';
	if(status=="show")
	{
		$('.imyie_flyingcart-tabs').html( w8window );
		intervalID = setInterval(function(){
			if($('.imyie_flyingcart-w8window-block').length>0)
			{
				$('.imyie_flyingcart-w8window-block'+cnt).css('backgroundColor',imyie_flyingcart_w8window_block_color);
				if(cnt==7)
				{
					$('.imyie_flyingcart-w8window-block').css('backgroundColor','#a5a5a5');
					cnt = 1;
				} else {
					cnt++;
				}
			} else {
				clearInterval(intervalID);
			}
		},100);
	} else if(status=="hide")
	{
		clearInterval(intervalID);
	}
}
function IMYIEFLYINGCART_ShowHideTabs(obj)
{
	var speed1 = 500;
	if( $(".imyie_flyingcart_inner").hasClass("svernut") || (obj!="" && !obj.hasClass("showed-tab")) )
	{
		$(".imyie_flyingcart_inner").animate({
			height: 250
		}, speed1,function(){
			$(this).addClass("razvernut");
			$(this).removeClass("svernut");
		});
	} else if( (obj!="" && obj.hasClass("showed-tab")) ) {
		$(".imyie_flyingcart_inner").animate({
			height: 30
		}, speed1,function(){
			$(this).addClass("svernut");
			$(this).removeClass("razvernut");
		});
	} else if( $(".imyie_flyingcart_inner").hasClass("razvernut") && obj=="" ) {
		$(".imyie_flyingcart_inner").animate({
			height: 30
		}, speed1,function(){
			$(this).addClass("svernut");
			$(this).removeClass("razvernut");
		});
	}
}

function IMYIEFLYINGCART_SwitchTabs(obj)
{
	var TabID = obj.attr("href");
	IMYIEFLYINGCART_ShowHideTabs( obj );
	$(".imyie_flyingcart-tab").hide();
	$(".imyie_flyingcart-" + TabID ).show();
	$(".imyie_flyingcart-header-a").removeClass("showed-tab");
	obj.addClass("showed-tab");
}

$(document).ready(function(){
	// add padding to body
	if(imyie_flyingcart_body_padding=="Y")
		$('body').css('paddingBottom', '30px');
	
	// change tab
	$(".imyie_flyingcart-header-a").bind("click",function(){
		IMYIEFLYINGCART_SwitchTabs( $(this) );
		return false;
	});
	
	// close when click on content
	$(".imyie_flyingcart_inner").bind("mouseenter",function(){
		$(this).addClass("mousehere");
	}).bind("mouseleave",function(){
		$(this).removeClass("mousehere");
	});
	$("html").bind("click",function(){
		if(!$(".imyie_flyingcart_inner").hasClass("mousehere") && $(".imyie_flyingcart_inner").hasClass("razvernut"))
		{
			IMYIEFLYINGCART_ShowHideTabs("");
		}
	});
	
	// plus/minus basket quantity
	$('.imyie_flyingcart-input_quantity_plus').live('click',function(){
		var quantity = parseInt( $('input[name="QUANTITY_'+$(this).data("id")+'"]').val() );
		$('input[name="QUANTITY_'+$(this).data("id")+'"]').val( (quantity+1) )
	});
	$('.imyie_flyingcart-input_quantity_minus').live('click',function(){
		var quantity = parseInt( $('input[name="QUANTITY_'+$(this).data("id")+'"]').val() );
		if(quantity>1)
			$('input[name="QUANTITY_'+$(this).data("id")+'"]').val( (quantity-1) )
	});
	
	// ajax request viewed (add2basket)
	$('.imyie_flyingcart-button_add2basket').live('click',function(){
		var ID = $(this).data('id');
		IMYIEFLYINGCART_w8window("show");
		$.ajax({
			url: imyie_flyingcart_ajax_path + '?mode=imyie_flyingcart_ajax' + '&add_id=' + ID + '&showed_tab=viewed',
			dataType : "html",
			success: function (html){
				$('.imyie_flyingcart-tabs').html( html );
			}               
		});
		return false;
	});
	
	// ajax request basket
	$('.imyie_flyingcart-basket-form').live('submit',function(){
		var data = $(this).serialize();
		data = data + '&' + $('.imyie_flyingcart-button_refresh').attr('name') + '=' + $('.imyie_flyingcart-button_refresh').attr('value');
		IMYIEFLYINGCART_w8window("show");
		$.ajax({
			url: imyie_flyingcart_ajax_path + '?mode=imyie_flyingcart_ajax' + '&showed_tab=basket',
			dataType : "html",
			data: data,
			success: function (html){
				$('.imyie_flyingcart-tabs').html( html );
			}               
		});
		return false;
	});
	$('.imyie_flyingcart-input_quantity_delete').live('click',function(){
		var ID = $(this).attr('id');
		$('#DELETE_'+ID).attr('checked',true);
		$('#flyingbasketBasketRefresh').click();
	});
	
	
});