<?require_once($_SERVER['DOCUMENT_ROOT'] . "/bitrix/modules/main/include/prolog_before.php");

$APPLICATION->IncludeComponent(
	"imyie:flyingcart",
	"",
Array(),
false
);

?>