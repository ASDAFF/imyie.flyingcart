<?
$arTooltips = array(

);
?>