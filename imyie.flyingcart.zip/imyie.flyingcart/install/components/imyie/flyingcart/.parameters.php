<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if(!CModule::IncludeModule('imyie.flyingcart'))
{
	ShowError("IMYIE_ERROR_MODULE_NOT_INSTALLED");
	return;
}
if(!CModule::IncludeModule('sale'))
{
	ShowError("IMYIE_ERROR_SALE_NOT_INSTALLED");
	return;
}
if(!CModule::IncludeModule('iblock'))
{
	ShowError("IMYIE_ERROR_IBLOCK_NOT_INSTALLED");
	return;
}
if(!CModule::IncludeModule('catalog'))
{
	ShowError("IMYIE_ERROR_CATALOG_NOT_INSTALLED");
	return;
}
?>