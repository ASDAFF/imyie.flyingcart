<?if(!check_bitrix_sessid()) return;?>
<?
IncludeModuleLangFile(__FILE__);
echo CAdminMessage::ShowNote(GetMessage("MOD_INST_OK"));
?>
<form action="<?echo $APPLICATION->GetCurPage()?>">
	<input type="hidden" name="lang" value="<?echo LANG?>">
	<input type="submit" name="" value="<?echo GetMessage("MOD_BACK")?>">
</form>
<form action="/bitrix/admin/settings.php">
	<input type="hidden" name="lang" value="<?=LANG?>">
	<input type="hidden" name="mid" value="imyie.flyingcart">
	<input type="submit" name="" value="<?=GetMessage("MOD_SETTINGS")?>">
</form>