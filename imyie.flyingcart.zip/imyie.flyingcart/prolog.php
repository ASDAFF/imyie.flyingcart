<?
define('ADMIN_MODULE_NAME', 'imyie.flyingcart');
define('ADMIN_MODULE_ICON', '');
?>