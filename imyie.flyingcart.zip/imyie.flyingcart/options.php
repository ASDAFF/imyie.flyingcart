<?if(!$USER->IsAdmin()) return;

IncludeModuleLangFile(__FILE__);

CModule::IncludeModule('imyie.flyingcart');
CModule::IncludeModule("catalog");

if(isset($_REQUEST["save"]) && check_bitrix_sessid())
{
	/* component params */
	$addType = ($_REQUEST["flyingcart_add_type"]=="auto" ? "auto" : "sam");
	COption::SetOptionString("imyie.flyingcart", "flyingcart_add_type", $addType );
	if($addType=="auto")
	{
		RegisterModuleDependences("main", "OnProlog", "imyie.flyingcart", "CIMYIEFlyingCart", "OnPrologHandler", "500");
		RegisterModuleDependences("main", "OnEpilog", "imyie.flyingcart", "CIMYIEFlyingCart", "OnEpilogHandler", "500");
	} else {
		UnRegisterModuleDependences("main", "OnProlog", "imyie.flyingcart", "CIMYIEFlyingCart", "OnPrologHandler");
		UnRegisterModuleDependences("main", "OnEpilog", "imyie.flyingcart", "CIMYIEFlyingCart", "OnEpilogHandler");
	}
	COption::SetOptionInt("imyie.flyingcart", "IBLOCK_ID", IntVal($_REQUEST["IBLOCK_ID"]) );
	COption::SetOptionString("imyie.flyingcart", "flyingcart_price_code", htmlspecialchars($_REQUEST["flyingcart_price_code"]) );
	COption::SetOptionString("imyie.flyingcart", "flyingcart_currency_id", $_REQUEST["flyingcart_currency_id"] );
	COption::SetOptionString("imyie.flyingcart", "flyingcart_tab_viewed_name", htmlspecialchars($_REQUEST["flyingcart_tab_viewed_name"]) );
	COption::SetOptionString("imyie.flyingcart", "flyingcart_tab_basket_name", htmlspecialchars($_REQUEST["flyingcart_tab_basket_name"]) );
	COption::SetOptionString("imyie.flyingcart", "flyingcart_link_order_make", htmlspecialchars($_REQUEST["flyingcart_link_order_make"]) );
	COption::SetOptionString("imyie.flyingcart", "flyingcart_overflow_viewed", ($_REQUEST["flyingcart_overflow_viewed"]=="Y" ? "Y" : "N") );
	COption::SetOptionInt("imyie.flyingcart", "flyingcart_viewed_count", IntVal($_REQUEST["flyingcart_viewed_count"]) );
	COption::SetOptionString("imyie.flyingcart", "flyingcart_body_padding", ($_REQUEST["flyingcart_body_padding"]=="Y" ? "Y" : "N") );
	COption::SetOptionString("imyie.flyingcart", "flyingcart_add_jquery", ($_REQUEST["flyingcart_add_jquery"]=="Y" ? "Y" : "N") );
	/* vision settings (styles) */
	CIMYIEFlyingCartStyle::GeneratorCSSAndRewrite();
	/* page excteption */
	$arrPageExecList = array();
	foreach(explode("\n",$_REQUEST["flyingcart_pageexc_list"]) as $url)
	{
		if(trim($url)!="")
			$arrPageExecList[] = trim($url);
	}
	COption::SetOptionString("imyie.flyingcart", "flyingcart_pageexc_type", htmlspecialchars($_REQUEST["flyingcart_pageexc_type"]) );
	COption::SetOptionString("imyie.flyingcart", "flyingcart_pageexc_list", serialize($arrPageExecList) );
}

$aTabs = array(
	array("DIV" => "imyie_tab1", "TAB" => GetMessage("IMYIE_SETTINGS"), "ICON" => "settings", "TITLE" => GetMessage("IMYIE_SETTINGS_TITLE")),
	array("DIV" => "imyie_tab2", "TAB" => GetMessage("IMYIE_VISUAL"), "ICON" => "settings", "TITLE" => GetMessage("IMYIE_VISUAL_TITLE")),
	array("DIV" => "imyie_tab3", "TAB" => GetMessage("IMYIE_PAGEEXCTEPTION"), "ICON" => "settings", "TITLE" => GetMessage("IMYIE_PAGEEXCTEPTION_TITLE")),
);
$tabControl = new CAdminTabControl("tabControl", $aTabs);
?>




<?$tabControl->Begin();?>
<?
$arPrice = array();
$rsPrice = CCatalogGroup::GetList($v1="sort", $v2="asc");
while($arr = $rsPrice->Fetch())
	$arPrice[$arr["NAME"]] = "[".$arr["NAME"]."] ".$arr["NAME_LANG"];

$arCurrencyList = array();
$rsCurrencies = CCurrency::GetList(($by = 'SORT'), ($order = 'ASC'));
while ($arCurrency = $rsCurrencies->Fetch())
{
	$arCurrencyList[$arCurrency['CURRENCY']] = $arCurrency['CURRENCY'];
}
?>
<script type="text/javascript">
function OnColorPicker(val,obj)
{
	document.getElementById(obj.oPar.id).value = val;
}
</script>
<form method="post" action="<?=$APPLICATION->GetCurPage()?>?mid=<?=urlencode($mid)?>&amp;lang=<?=LANGUAGE_ID?>">






<?$tabControl->BeginNextTab();?>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_ADD_TYPE")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_add_type = COption::GetOptionString("imyie.flyingcart", "flyingcart_add_type", "auto" );?>
			<input type="radio" name="flyingcart_add_type" id="flyingcart_add_type_auto" value="auto"<?if($flyingcart_add_type=="auto"):?> checked<?endif;?> /><label for="flyingcart_add_type_auto"><?=GetMessage("IMYIE_FLYINGCART_AUTO")?></label><br />
			<input type="radio" name="flyingcart_add_type" id="flyingcart_add_type_sam" value="sam"<?if($flyingcart_add_type=="sam"):?> checked<?endif;?>/><label for="flyingcart_add_type_sam"><?=GetMessage("IMYIE_FLYINGCART_SAM")?></label>
		</td>
	</tr>
	<tr class="heading">
		<td colspan="2"><?=GetMessage("IMYIE_FLYINGCART_COMPONENTS_SETTINGS")?></td>
	</tr>
	<tr>
		<?$IBLOCK_ID = COption::GetOptionInt("imyie.flyingcart", "IBLOCK_ID", 0 );?>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_IBLOCK_ID")?>:</td>
		<td valign="top" width="50%"><?=GetIBlockDropDownList($IBLOCK_ID, "IBLOCK_TYPE_ID", "IBLOCK_ID");?></td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_PRICE_CODE")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_price_code = COption::GetOptionString("imyie.flyingcart", "flyingcart_price_code");?>
			<select name="flyingcart_price_code">
				<?foreach($arPrice as $key => $price):?>
					<option value="<?=$key?>"<?if($flyingcart_price_code==$key):?> selected <?endif;?>><?=$price?></option>
				<?endforeach;?>
			</select>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_CURRENCY_ID")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_currency_id = COption::GetOptionString("imyie.flyingcart", "flyingcart_currency_id");?>
			<select name="flyingcart_currency_id">
				<?foreach($arCurrencyList as $key => $currency):?>
					<option value="<?=$key?>"<?if($flyingcart_currency_id==$key):?> selected <?endif;?>><?=$currency?></option>
				<?endforeach;?>
			</select>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_TAB_VIEWED_NAME")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_tab_viewed_name = COption::GetOptionString("imyie.flyingcart", "flyingcart_tab_viewed_name");?>
			<input type="text" name="flyingcart_tab_viewed_name" value="<?=$flyingcart_tab_viewed_name?>" />
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_TAB_BASKET_NAME")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_tab_basket_name = COption::GetOptionString("imyie.flyingcart", "flyingcart_tab_basket_name");?>
			<input type="text" name="flyingcart_tab_basket_name" value="<?=$flyingcart_tab_basket_name?>" />
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_LINK_ORDER_MAKE")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_link_order_make = COption::GetOptionString("imyie.flyingcart", "flyingcart_link_order_make");?>
			<input type="text" name="flyingcart_link_order_make" value="<?=$flyingcart_link_order_make?>" />
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_OVERFLOW_VIEWED")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_overflow_viewed = COption::GetOptionString("imyie.flyingcart", "flyingcart_overflow_viewed");?>
			<input type="checkbox" name="flyingcart_overflow_viewed" value="Y"<?if($flyingcart_overflow_viewed=="Y"):?> checked="checked"<?endif;?>/>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VIEWED_COUNT")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_viewed_count = COption::GetOptionInt("imyie.flyingcart", "flyingcart_viewed_count");?>
			<input type="text" name="flyingcart_viewed_count" value="<?=$flyingcart_viewed_count?>" />
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_ADD_BODY_PADDING")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_body_padding = COption::GetOptionString("imyie.flyingcart", "flyingcart_body_padding");?>
			<input type="checkbox" name="flyingcart_body_padding" value="Y"<?if($flyingcart_body_padding=="Y"):?> checked="checked"<?endif;?>/>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_ADD_JQUERY")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_add_jquery = COption::GetOptionString("imyie.flyingcart", "flyingcart_add_jquery", "Y");?>
			<input type="checkbox" name="flyingcart_add_jquery" value="Y"<?if($flyingcart_add_jquery=="Y"):?> checked="checked"<?endif;?>/>
		</td>
	</tr>
	
	
	
	

<?$tabControl->BeginNextTab();?>
<?$data_styles = CIMYIEFlyingCartStyle::GetSets();?>
<script>
var imyie_flyingcart_datas = <?=CUtil::PhpToJSObject($data_styles);?>;
function imyie_flyingcart_set_datas(color_name)
{
	for(var key in imyie_flyingcart_datas[color_name].DATA)
	{
		if(imyie_flyingcart_datas[color_name].DATA.hasOwnProperty(key))
		{
			document.getElementById(key).value = imyie_flyingcart_datas[color_name].DATA[key];
		}
	}
}
</script>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_COLOR_DATA")?>:</td>
		<td valign="top" width="50%">
			<select name="datas" onchange="imyie_flyingcart_set_datas(this.value);">
				<option value="-">-</option>
			<?
			foreach($data_styles as $key => $datas)
			{
				echo "<option value=\"".$key."\">".$datas["NAME"]."</option>";
			}
			?>
			</select>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_WIDTH")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_visual_width = COption::GetOptionInt("imyie.flyingcart", "flyingcart_visual_width", 80);?>
			<?$flyingcart_visual_width_pesr_px = COption::GetOptionString("imyie.flyingcart", "flyingcart_visual_width_pesr_px", "%");?>
			<input type="text" name="flyingcart_visual_width" id="flyingcart_visual_width" value="<?=$flyingcart_visual_width?>" />
			<select name="flyingcart_visual_width_pesr_px" id="flyingcart_visual_width_pesr_px">
				<option value="%"<?if($flyingcart_visual_width_pesr_px=="%"):?> selected <?endif;?>>%</option>
				<option value="px"<?if($flyingcart_visual_width_pesr_px=="px"):?> selected <?endif;?>>px</option>
			</select>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_HEADER_BORDER")?>:</td>
		<td valign="top" width="50%"><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_header_border", "#13395a");?></td>
	</tr>
	<tr>
		<td valign="top" colspan="2">
			<?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_HEADER_BG")?>
			<table class="internal" border="0" cellspacing="0" cellpadding="0">
				<tr class="heading">
					<td>&nbsp;</td>
					<td colspan="2"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TH_NOTACTIVE")?></td>
					<td colspan="2"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TH_ACTIVE")?></td>
				</tr>
				<tr class="heading">
					<td>&nbsp;</th>
					<td><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TH_NOTAC_SAMPLE")?></td>
					<td><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TH_NOTAC_HOVER")?></td>
					<td><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TH_SAMPLE")?></td>
					<td><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TH_HOVER")?></td>
				</tr>
				<tr>
					<td><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TD_FULL_BG")?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_old_sver", "#124f85");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_old_sverhover", "#124f85");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_old_razv", "#124f85");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_old_razvhover", "#124f85");?></td>
				</tr>
				<tr>
					<td><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TD_FULL_BG_GRADSTART")?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_gradstart_sver", "#124f85");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_gradstart_sverhover", "#124f85");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_gradstart_razv", "#124f85");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_gradstart_razvhover", "#124f85");?></td>
				</tr>
				<tr>
					<td><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TD_FULL_BG_GRADEND")?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_gradend_sver", "#2b7fbf");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_gradend_sverhover", "#2b7fbf");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_gradend_razv", "#2b7fbf");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_full_header_bg_gradend_razvhover", "#2b7fbf");?></td>
				</tr>
				<tr>
					<td><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TD_TEXT_COLOR")?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_header_text_sver", "#FFFFFF");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_header_text_sverhover", "#FFFFFF");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_header_text_razv", "#000000");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_header_text_razvhover", "#F66B0E");?></td>
				</tr>
				<tr>
					<td><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TD_TAB_BG")?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_old_sver", "#296ca8");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_old_sverhover", "#3c94d7");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_old_razv", "#FFFFFF");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_old_razvhover", "#FFFFFF");?></td>
				</tr>
				<tr>
					<td><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TD_TAB_BG_GRADSTART")?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_gradstart_sver", "#124f85");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_gradstart_sverhover", "#2b7fbf");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_gradstart_razv", "#FFFFFF");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_gradstart_razvhover", "#FFFFFF");?></td>
				</tr>
				<tr>
					<td><?=GetMessage("IMYIE_FLYINGCART_VISUAL_TABLE_TD_TAB_BG_GRADEND")?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_gradend_sver", "#2b7fbf");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_gradend_sverhover", "#2b7fbf");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_gradend_razv", "#FFFFFF");?></td>
					<td><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_tab_header_bg_gradend_razvhover", "#FFFFFF");?></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_LINK")?>:</td>
		<td valign="top" width="50%"><!-- link color --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_link", "#124F85");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_LINK1")?><br />
			<!-- link color:hover --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_link_hover", "#3F96E4");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_LINK2")?>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_INBASKET")?>:</td>
		<td valign="top" width="50%"><!-- bg color --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_inbasket_bg", "#3f96e4");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_INBASKET_BG")?><br />
			<!-- text color --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_inbasket_text", "#FFFFFF");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_INBASKET_TEXT")?>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_OLDPRICE")?>:</td>
		<td valign="top" width="50%"><!-- bg color --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_oldprice_bg", "#999999");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_OLDPRICE_BG")?><br />
			<!-- text color --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_oldprice_text", "#FFFFFF");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_OLDPRICE_TEXT")?>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_PRICE")?>:</td>
		<td valign="top" width="50%"><!-- bg color --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_price_bg", "#124F85");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_PRICE_BG")?><br />
			<!-- text color --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_price_text", "#FFFFFF");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_PRICE_TEXT")?>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_BTN")?>:</td>
		<td valign="top" width="50%"><!-- bg color --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_btn_bg", "#124F85");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_BTN_BG")?><br />
			<!-- text color --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_btn_text", "#FFFFFF");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_BTN_TEXT")?><br />
			<!-- bg color:hover --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_btn_bg_hover", "#3b92c6");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_BTN_HOVER")?>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_BTN_DELETE")?>:</td>
		<td valign="top" width="50%"><!-- bg color --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_btn_delete_bg", "#ff0000");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_BTN_BG")?><br />
			<!-- text color --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_btn_delete_text", "#FFFFFF");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_BTN_TEXT")?><br />
			<!-- bg color:hover --><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_btn_delete_bg_hover", "#c53737");?><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_BTN_HOVER")?>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_INPUT_BORDER")?>:</td>
		<td valign="top" width="50%"><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_input_border", "#124F85");?></td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_NOTE")?>:</td>
		<td valign="top" width="50%"><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_note", "#124F85");?></td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_VISUAL_COLOR_PROGRESS_BAR")?>:</td>
		<td valign="top" width="50%"><?CIMYIEFlyingCartStyle::ShowBColorPicker("flyingcart_visual_color_progress_bar", "#124F85");?></td>
	</tr>

	
	
	
	
<?$tabControl->BeginNextTab();?>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_PAGEEXC_TYPE")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_pageexc_type = COption::GetOptionString("imyie.flyingcart", "flyingcart_pageexc_type", "none");?>
			<label><input type="radio" name="flyingcart_pageexc_type" value="none"<?if($flyingcart_pageexc_type=="none"):?> checked="checked"<?endif;?> /><?=GetMessage("IMYIE_FLYINGCART_PAGEEXC_TYPE_NONE")?></label><br />
			<label><input type="radio" name="flyingcart_pageexc_type" value="excteption"<?if($flyingcart_pageexc_type=="excteption"):?> checked="checked"<?endif;?> /><?=GetMessage("IMYIE_FLYINGCART_PAGEEXC_TYPE_EXCTEPTION")?></label><br />
			<label><input type="radio" name="flyingcart_pageexc_type" value="only"<?if($flyingcart_pageexc_type=="only"):?> checked="checked"<?endif;?> /><?=GetMessage("IMYIE_FLYINGCART_PAGEEXC_TYPE_ONLY")?></label>
		</td>
	</tr>
	<tr>
		<td valign="top" width="50%"><?=GetMessage("IMYIE_FLYINGCART_EXC_LIST")?>:</td>
		<td valign="top" width="50%">
			<?$flyingcart_pageexc_list = unserialize( COption::GetOptionString("imyie.flyingcart", "flyingcart_pageexc_list", "") );?>
			<textarea name="flyingcart_pageexc_list" rows="15" style="width:100%;"><?
			foreach($flyingcart_pageexc_list as $url)
			{
				echo $url."\n";
			}
			?></textarea>
		</td>
	</tr>
	
	



<?$tabControl->Buttons();?>
	<input type="submit" name="save" value="<?=GetMessage("IMYIE_LOGINBYEMAIL_BTN_SAVE")?>">
	<?=bitrix_sessid_post();?>
<?$tabControl->End();?>
</form>